# F.R.I.D.A.Y — AI Assistant

A production-grade, futuristic AI assistant inspired by JARVIS / FRIDAY (Iron Man),
Tron: Legacy holographic interfaces, and Cyberpunk 2077 HUDs. Features a massive
animated 3D neural brain, real-time voice interaction, streaming chat, memory
(short-term + long-term + vector search), and system automation.

---

## Architecture Overview

```
friday-ai/
├── frontend/   React + Vite + Three.js (R3F) + Tailwind + Framer Motion
├── backend/    FastAPI + WebSockets + LangGraph-style reasoning + ChromaDB
├── docker/     Dockerfiles + docker-compose for full-stack deployment
├── scripts/    Dev convenience scripts
├── tests/      Backend smoke tests
└── docs/       Additional documentation
```

### Frontend
- **React + Vite**: fast dev server, modular component architecture.
- **Three.js / React Three Fiber**: GPU-optimized 3D neural brain — a single
  `Points` draw call for 6,000 particles, animated synapse lines with traveling
  energy pulses, and a bloom-lit energy core that reacts to AI state.
- **Zustand store** (`src/store/fridayStore.js`): single source of truth for
  brain state, chat messages, voice amplitude, system stats, and notifications.
- **Voice**: Web Speech API for STT/TTS + wake-word ("Friday") detection in the
  browser, with a backend Whisper fallback (`/api/voice/stt`).
- **Tailwind CSS**: cyan/neon HUD theme, glassmorphism panels, HUD corner
  brackets, scanlines, and glow utilities defined in `tailwind.config.js` and
  `src/styles/global.css`.

### Backend
- **FastAPI**: REST + WebSocket API, modular routers under `app/api/`.
- **Reasoning engine** (`app/ai/reasoning.py`): orchestrates memory retrieval,
  intent planning, tool execution, and LLM streaming.
- **Planner** (`app/ai/planner.py`): lightweight intent classifier (open app,
  run command, system status, schedule task, or plain chat).
- **Memory engine**: short-term rolling buffer (in-process), long-term
  persistence (PostgreSQL), and semantic recall (ChromaDB vector search).
- **Tools** (`app/ai/tools.py`): open applications, execute whitelisted shell
  commands, and read live system stats (CPU/RAM/Disk/Network/GPU via
  `psutil` + `GPUtil`).
- **Voice**: `faster-whisper` for STT, `pyttsx3` for TTS, simple wake-word
  matching.
- **Automation**: APScheduler-backed cron task scheduling.

---

## Real-Time Communication

### Chat WebSocket — `ws://<host>/api/chat/ws/{conversation_id}`

Client → Server:
```json
{ "type": "user_message", "data": "open browser" }
```

Server → Client (streamed sequence):
```json
{ "type": "status", "data": "executing_tool" }
{ "type": "status", "data": "thinking" }
{ "type": "token", "data": "Open" }
{ "type": "token", "data": "ing " }
{ "type": "done", "data": { "full_text": "Opening browser..." } }
```

### System Stats WebSocket — `ws://<host>/api/system/ws/stats`
Pushes a JSON snapshot of CPU/RAM/Disk/Network/GPU every 2 seconds.

---

## Brain Visualization States

The 3D brain (`src/components/Brain/`) reacts to `brainState` in the global store:

| State       | Behavior                                                              |
|-------------|------------------------------------------------------------------------|
| `idle`      | Slow ambient pulse, calm cyan glow                                     |
| `listening` | Wider voice rings, faster particle pulse, mic-amplitude reactive       |
| `thinking`  | Fast synapse pulses, violet-shifted core, accelerated particle motion  |
| `speaking`  | Synced with TTS playback, moderate pulse                               |
| `alert`     | Amber/orange core, maximum pulse intensity                             |

---

## Local Development

### Prerequisites
- Node.js 20+
- Python 3.11+
- PostgreSQL 16 (or use Docker)

### Quick start (script)
```bash
./scripts/dev.sh
```
This sets up a Python venv, installs backend deps, starts FastAPI on `:8000`,
installs frontend deps, and starts Vite on `:5173`.

### Manual setup

**Backend:**
```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in OPENAI_API_KEY, DATABASE_URL, etc.
uvicorn app.main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Visit `http://localhost:5173`.

---

## Production Deployment

### Option 1: Docker Compose (recommended)
```bash
cd docker
docker compose up --build -d
```
This brings up PostgreSQL, the FastAPI backend (port 8000), and an Nginx-served
frontend build (port 80) that reverse-proxies `/api/*` to the backend,
including WebSocket upgrades.

### Option 2: Manual / Cloud
1. **Backend**: deploy the FastAPI app behind an ASGI server (uvicorn/gunicorn
   with `uvicorn.workers.UvicornWorker`) on a host with WebSocket support
   (e.g. Fly.io, Render, ECS, a VM behind Nginx). Provision PostgreSQL and a
   persistent volume for ChromaDB (`CHROMA_PERSIST_DIR`).
2. **Frontend**: build with `npm run build` and serve the `dist/` output via
   any static host (Vercel, Netlify, S3 + CloudFront, or Nginx). Set
   `VITE_API_BASE` / `VITE_WS_BASE` to your backend's public URL (use `wss://`
   for TLS).
3. **Environment variables**: set `OPENAI_API_KEY` for real LLM responses
   (without it, the backend runs in a deterministic mock-streaming mode).
4. **CORS**: update `ALLOWED_ORIGINS` in `backend/app/config.py` to your
   frontend's production domain.
5. **TLS**: terminate TLS at your reverse proxy/load balancer; ensure
   WebSocket upgrade headers (`Upgrade`, `Connection`) are forwarded.

---

## Extending FRIDAY

- **Swap LLM provider**: edit `app/ai/llm.py` (OpenAI-compatible interface).
- **Add tools**: register new async functions in `app/ai/tools.py` and route
  intents to them in `app/ai/planner.py` / `app/ai/reasoning.py`.
- **Higher-quality voice**: replace `pyttsx3` in `app/voice/tts.py` with a
  cloud TTS provider (ElevenLabs, Azure, OpenAI TTS) for more natural speech.
- **Dedicated wake-word model**: replace `app/voice/wakeword.py` with
  Porcupine/openWakeWord for low-latency, always-on detection.
- **Theming**: extend `tailwind.config.js` color tokens for alternate HUD
  themes (amber/violet variants are scaffolded in the Settings page).

---

## License
MIT — build your own JARVIS.
