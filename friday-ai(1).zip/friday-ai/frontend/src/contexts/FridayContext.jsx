import { createContext, useContext } from "react";

/**
 * FridayContext: lightweight context for app-wide config that doesn't
 * belong in the zustand store (e.g. feature flags, API base URLs).
 * Most reactive state lives in src/store/fridayStore.js.
 */
const FridayContext = createContext({
  apiBase: import.meta.env.VITE_API_BASE || "http://localhost:8000",
  wsBase: import.meta.env.VITE_WS_BASE || "ws://localhost:8000",
});

export function FridayProvider({ children }) {
  const value = {
    apiBase: import.meta.env.VITE_API_BASE || "http://localhost:8000",
    wsBase: import.meta.env.VITE_WS_BASE || "ws://localhost:8000",
  };

  return <FridayContext.Provider value={value}>{children}</FridayContext.Provider>;
}

export function useFridayContext() {
  return useContext(FridayContext);
}
