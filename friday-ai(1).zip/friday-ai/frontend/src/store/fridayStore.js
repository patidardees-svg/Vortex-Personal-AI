import { create } from "zustand";

/**
 * Central application state for FRIDAY.
 * - brainState: drives the 3D brain visualization (idle/listening/thinking/speaking)
 * - messages: chat conversation history
 * - systemStats: live CPU/RAM/GPU/network data
 * - voice: mic/listening state and live waveform amplitude
 */
export const useFridayStore = create((set, get) => ({
  // ---------------- Brain / AI state ----------------
  brainState: "idle", // idle | listening | thinking | speaking | alert
  setBrainState: (state) => set({ brainState: state }),

  // ---------------- Conversation ----------------
  conversationId: null,
  messages: [],
  isStreaming: false,
  setConversationId: (id) => set({ conversationId: id }),

  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),

  appendToLastMessage: (delta) =>
    set((state) => {
      const messages = [...state.messages];
      const last = messages[messages.length - 1];
      if (last && last.role === "assistant") {
        messages[messages.length - 1] = { ...last, content: last.content + delta };
      }
      return { messages };
    }),

  setStreaming: (val) => set({ isStreaming: val }),

  clearMessages: () => set({ messages: [] }),

  // ---------------- Voice ----------------
  isListening: false,
  micAmplitude: 0,
  setListening: (val) => set({ isListening: val }),
  setMicAmplitude: (val) => set({ micAmplitude: val }),

  // ---------------- System stats ----------------
  systemStats: {
    cpu: 0,
    ram: { percent: 0, used: 0, total: 0 },
    disk: { percent: 0, used: 0, total: 0 },
    network: { sent: 0, recv: 0 },
    gpu: [],
  },
  setSystemStats: (stats) => set({ systemStats: stats }),

  // ---------------- Notifications ----------------
  notifications: [],
  pushNotification: (notification) =>
    set((state) => ({
      notifications: [
        { id: crypto.randomUUID(), timestamp: Date.now(), ...notification },
        ...state.notifications,
      ].slice(0, 20),
    })),
  dismissNotification: (id) =>
    set((state) => ({
      notifications: state.notifications.filter((n) => n.id !== id),
    })),
}));
