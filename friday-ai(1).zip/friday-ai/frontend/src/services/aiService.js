/**
 * REST helpers for chat/conversation management.
 */

const API_BASE = (import.meta.env.VITE_API_BASE || "http://localhost:8000").replace(/\/$/, "");

export async function createConversation() {
  const res = await fetch(`${API_BASE}/api/chat/new`);
  const data = await res.json();
  return data.conversation_id;
}

export async function fetchHistory(conversationId) {
  const res = await fetch(`${API_BASE}/api/chat/history/${conversationId}`);
  const data = await res.json();
  return data.messages || [];
}
