/**
 * WebSocket service: manages the connection to FRIDAY's chat WebSocket,
 * dispatching structured events to registered listeners.
 */

const WS_BASE = (import.meta.env.VITE_WS_BASE || "ws://localhost:8000").replace(/\/$/, "");

export class ChatSocket {
  constructor(conversationId) {
    this.conversationId = conversationId;
    this.socket = null;
    this.listeners = new Set();
    this.reconnectTimer = null;
  }

  connect() {
    const url = `${WS_BASE}/api/chat/ws/${this.conversationId}`;
    this.socket = new WebSocket(url);

    this.socket.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        this.listeners.forEach((fn) => fn(payload));
      } catch (err) {
        console.error("Failed to parse WS message", err);
      }
    };

    this.socket.onclose = () => {
      this.reconnectTimer = setTimeout(() => this.connect(), 2000);
    };

    this.socket.onerror = (err) => {
      console.error("WebSocket error", err);
    };
  }

  send(text) {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({ type: "user_message", data: text }));
    }
  }

  subscribe(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  disconnect() {
    clearTimeout(this.reconnectTimer);
    this.socket?.close();
  }
}

/**
 * Generic system stats WebSocket (CPU/RAM/GPU dashboard feed).
 */
export class SystemStatsSocket {
  constructor() {
    this.socket = null;
    this.listeners = new Set();
    this.reconnectTimer = null;
  }

  connect() {
    const url = `${WS_BASE}/api/system/ws/stats`;
    this.socket = new WebSocket(url);

    this.socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        this.listeners.forEach((fn) => fn(data));
      } catch (err) {
        console.error("Failed to parse stats message", err);
      }
    };

    this.socket.onclose = () => {
      this.reconnectTimer = setTimeout(() => this.connect(), 2000);
    };
  }

  subscribe(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  disconnect() {
    clearTimeout(this.reconnectTimer);
    this.socket?.close();
  }
}
