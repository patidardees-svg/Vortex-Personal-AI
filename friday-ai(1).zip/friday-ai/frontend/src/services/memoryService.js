/**
 * REST helpers for memory inspection: short-term buffer,
 * semantic vector search, and user profile facts.
 */

const API_BASE = (import.meta.env.VITE_API_BASE || "http://localhost:8000").replace(/\/$/, "");

export async function getShortTermMemory(conversationId) {
  const res = await fetch(`${API_BASE}/api/memory/short-term/${conversationId}`);
  const data = await res.json();
  return data.messages || [];
}

export async function semanticSearch(query, topK = 5) {
  const res = await fetch(`${API_BASE}/api/memory/search`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, top_k: topK }),
  });
  const data = await res.json();
  return data.results || [];
}

export async function getUserProfile() {
  const res = await fetch(`${API_BASE}/api/memory/profile`);
  return res.json();
}

export async function setUserProfileFact(key, value) {
  const res = await fetch(`${API_BASE}/api/memory/profile`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key, value }),
  });
  return res.json();
}
