/**
 * Voice service: wraps the browser's SpeechRecognition (Web Speech API)
 * for low-latency STT + wake-word detection, the browser's
 * SpeechSynthesis API for TTS, and falls back to the backend
 * /api/voice endpoints for higher-quality processing when needed.
 */

const API_BASE = (import.meta.env.VITE_API_BASE || "http://localhost:8000").replace(/\/$/, "");
const WAKE_WORD = "friday";

const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition || null;

export class VoiceController {
  constructor({ onResult, onWakeWord, onAmplitude, onListeningChange } = {}) {
    this.onResult = onResult;
    this.onWakeWord = onWakeWord;
    this.onAmplitude = onAmplitude;
    this.onListeningChange = onListeningChange;

    this.recognition = null;
    this.audioContext = null;
    this.analyser = null;
    this.mediaStream = null;
    this.rafId = null;
  }

  // ---------------- Speech to text (continuous, wake-word listening) ----------------
  startListening() {
    if (!SpeechRecognition) {
      console.warn("SpeechRecognition not supported in this browser.");
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = "en-US";

    this.recognition.onresult = (event) => {
      const result = event.results[event.results.length - 1];
      const transcript = result[0].transcript.trim();

      if (transcript.toLowerCase().includes(WAKE_WORD)) {
        this.onWakeWord?.(transcript);
      }

      if (result.isFinal) {
        this.onResult?.(transcript);
      }
    };

    this.recognition.onend = () => {
      // Auto-restart for continuous wake-word detection
      if (this._shouldRestart) {
        this.recognition.start();
      } else {
        this.onListeningChange?.(false);
      }
    };

    this._shouldRestart = true;
    this.recognition.start();
    this.onListeningChange?.(true);
    this._startAmplitudeAnalysis();
  }

  stopListening() {
    this._shouldRestart = false;
    this.recognition?.stop();
    this._stopAmplitudeAnalysis();
    this.onListeningChange?.(false);
  }

  // ---------------- Microphone amplitude (for waveform visualization) ----------------
  async _startAmplitudeAnalysis() {
    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const source = this.audioContext.createMediaStreamSource(this.mediaStream);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      source.connect(this.analyser);

      const dataArray = new Uint8Array(this.analyser.frequencyBinCount);

      const tick = () => {
        this.analyser.getByteFrequencyData(dataArray);
        const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
        this.onAmplitude?.(avg / 255);
        this.rafId = requestAnimationFrame(tick);
      };
      tick();
    } catch (err) {
      console.warn("Microphone access denied or unavailable:", err);
    }
  }

  _stopAmplitudeAnalysis() {
    if (this.rafId) cancelAnimationFrame(this.rafId);
    this.mediaStream?.getTracks().forEach((track) => track.stop());
    this.audioContext?.close();
  }

  // ---------------- Text to speech ----------------
  speak(text, { onStart, onEnd } = {}) {
    if (!window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.lang = "en-US";

    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find((v) => /female|samantha|zira/i.test(v.name));
    if (preferred) utterance.voice = preferred;

    utterance.onstart = () => onStart?.();
    utterance.onend = () => onEnd?.();

    window.speechSynthesis.speak(utterance);
  }

  // ---------------- Backend STT fallback ----------------
  async transcribeAudioBlob(blob) {
    const formData = new FormData();
    formData.append("audio", blob, "audio.wav");

    const res = await fetch(`${API_BASE}/api/voice/stt`, {
      method: "POST",
      body: formData,
    });
    return res.json();
  }
}
