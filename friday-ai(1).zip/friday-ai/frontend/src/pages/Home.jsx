import { useEffect, useState } from "react";
import { Brain, Database, Cog, Settings as SettingsIcon } from "lucide-react";
import { NavLink } from "react-router-dom";

import NeuralBrain from "../components/Brain/NeuralBrain";
import VoiceWave from "../components/Voice/VoiceWave";
import ChatWindow from "../components/Chat/ChatWindow";
import HolographicPanel from "../components/Hologram/HolographicPanel";
import FloatingWidgets from "../components/Hologram/FloatingWidgets";
import HumanHologramView from "../components/Hologram/HumanHologramView";
import SystemStats from "../components/Dashboard/SystemStats";

import { useFridayStore } from "../store/fridayStore";
import { useChatSocket } from "../hooks/useChatSocket";
import { useSystemStats } from "../hooks/useSystemStats";
import { useVoice } from "../hooks/useVoice";
import { createConversation } from "../services/aiService";

const NAV_LINKS = [
  { to: "/", label: "Core", icon: <Brain size={16} /> },
  { to: "/memory", label: "Memory", icon: <Database size={16} /> },
  { to: "/automation", label: "Automation", icon: <Cog size={16} /> },
  { to: "/settings", label: "Settings", icon: <SettingsIcon size={16} /> },
];

/**
 * Main HUD screen: animated brain core, voice ring, side panels
 * (memory/automation on the left, system status/notifications on
 * the right), and the bottom chat console.
 */
export default function Home() {
  const conversationId = useFridayStore((s) => s.conversationId);
  const setConversationId = useFridayStore((s) => s.setConversationId);
  const brainState = useFridayStore((s) => s.brainState);

  useSystemStats();

  useEffect(() => {
    if (!conversationId) {
      createConversation().then(setConversationId);
    }
  }, [conversationId]);

  const { sendMessage } = useChatSocket(conversationId);

  const { toggleListening, speak } = useVoice({
    onTranscript: (text) => {
      sendMessage(text);
    },
  });

  // Speak the assistant's final response aloud
  const messages = useFridayStore((s) => s.messages);
  const [lastSpoken, setLastSpoken] = useState(null);
  useEffect(() => {
    const last = messages[messages.length - 1];
    if (last?.role === "assistant" && !useFridayStore.getState().isStreaming && last.content && last.id !== lastSpoken) {
      speak(last.content);
      setLastSpoken(last.id);
    }
  }, [messages]);

  return (
    <div className="relative grid h-screen grid-rows-[auto_1fr_auto] gap-3 p-4 lg:p-6">
      <FloatingWidgets />

      {/* Top bar */}
      <header className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-xl font-bold uppercase tracking-[0.3em] text-cyan-glow text-glow">
            F.R.I.D.A.Y
          </h1>
          <p className="font-mono text-[11px] uppercase tracking-widest text-cyan-glow/40">
            Status: {brainState.toUpperCase()}
          </p>
        </div>

        <nav className="flex gap-2">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-display uppercase tracking-widest transition-all
                ${isActive
                  ? "border-cyan-glow/50 bg-cyan-core/10 text-cyan-glow shadow-glow-cyan"
                  : "border-cyan-glow/10 text-slate-400 hover:border-cyan-glow/30 hover:text-cyan-glow"}`
              }
            >
              {link.icon}
              <span className="hidden sm:inline">{link.label}</span>
            </NavLink>
          ))}
        </nav>
      </header>

      {/* Main grid: left panels | brain | right panels */}
      <main className="grid grid-cols-1 gap-4 lg:grid-cols-[260px_1fr_260px]">
        {/* Left panel */}
        <div className="hidden flex-col gap-4 lg:flex">
          <HolographicPanel title="System Status" className="flex-1">
            <SystemStats />
            <div className="mt-4 border-t border-cyan-glow/10 pt-3">
              <HumanHologramView />
            </div>
          </HolographicPanel>
        </div>

        {/* Brain core */}
        <div className="relative flex items-center justify-center">
          <div className="relative aspect-square w-full max-w-[640px]">
            <NeuralBrain />
            <VoiceWave />
          </div>
        </div>

        {/* Right panel */}
        <div className="hidden flex-col gap-4 lg:flex">
          <HolographicPanel title="Memory Buffer" className="flex-1">
            <div className="space-y-2 text-xs text-slate-400 font-body">
              {messages.slice(-6).map((m) => (
                <div key={m.id} className="truncate">
                  <span className="text-cyan-glow/60 uppercase mr-1">{m.role}:</span>
                  {m.content || "..."}
                </div>
              ))}
              {messages.length === 0 && <div>No active session memory.</div>}
            </div>
          </HolographicPanel>
        </div>
      </main>

      {/* Bottom chat console */}
      <footer className="h-64 lg:h-72">
        <ChatWindow onSend={sendMessage} onToggleMic={toggleListening} />
      </footer>
    </div>
  );
}
