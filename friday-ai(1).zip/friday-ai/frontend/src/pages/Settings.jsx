import { useState } from "react";
import HolographicPanel from "../components/Hologram/HolographicPanel";
import { Settings as SettingsIcon, Mic, Palette, Cpu } from "lucide-react";
import { useFridayStore } from "../store/fridayStore";

/**
 * Settings page: voice, appearance, and system preferences.
 * Persists only in-session (wire up to /api/memory/profile for persistence).
 */
export default function Settings() {
  const clearMessages = useFridayStore((s) => s.clearMessages);
  const [wakeWord, setWakeWord] = useState("friday");
  const [voiceSpeed, setVoiceSpeed] = useState(1.0);
  const [theme, setTheme] = useState("cyan");

  return (
    <div className="grid h-screen grid-cols-1 gap-4 p-6 lg:grid-cols-3">
      <HolographicPanel title="Voice Settings" icon={<Mic size={14} />}>
        <div className="space-y-4 text-xs font-body text-slate-300">
          <div>
            <label className="mb-1 block text-cyan-glow/70">Wake Word</label>
            <input
              value={wakeWord}
              onChange={(e) => setWakeWord(e.target.value)}
              className="w-full rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2
                text-slate-100 outline-none focus:border-cyan-glow/50"
            />
          </div>
          <div>
            <label className="mb-1 block text-cyan-glow/70">Voice Speed: {voiceSpeed.toFixed(1)}x</label>
            <input
              type="range"
              min="0.5"
              max="2"
              step="0.1"
              value={voiceSpeed}
              onChange={(e) => setVoiceSpeed(parseFloat(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </div>
        </div>
      </HolographicPanel>

      <HolographicPanel title="Appearance" icon={<Palette size={14} />}>
        <div className="space-y-3 text-xs font-body text-slate-300">
          <label className="mb-1 block text-cyan-glow/70">HUD Color Theme</label>
          <div className="flex gap-2">
            {["cyan", "amber", "violet"].map((c) => (
              <button
                key={c}
                onClick={() => setTheme(c)}
                className={`h-8 flex-1 rounded-lg border text-[10px] uppercase tracking-widest
                  ${theme === c ? "border-cyan-glow bg-cyan-core/20 text-cyan-glow" : "border-cyan-glow/10 text-slate-400"}`}
              >
                {c}
              </button>
            ))}
          </div>
          <p className="text-slate-500">
            Theme switching is wired through Tailwind tokens — extend{" "}
            <code className="text-cyan-glow/70">tailwind.config.js</code> to add palettes.
          </p>
        </div>
      </HolographicPanel>

      <HolographicPanel title="System" icon={<Cpu size={14} />}>
        <div className="space-y-3 text-xs font-body text-slate-300">
          <button
            onClick={clearMessages}
            className="w-full rounded-lg border border-cyan-glow/30 bg-cyan-core/10 py-2
              font-display uppercase tracking-widest text-cyan-glow hover:bg-cyan-core/20"
          >
            Clear Session Memory
          </button>
          <div className="flex items-center gap-2 text-cyan-glow/60">
            <SettingsIcon size={14} />
            FRIDAY v1.0.0 — Production Build
          </div>
        </div>
      </HolographicPanel>
    </div>
  );
}
