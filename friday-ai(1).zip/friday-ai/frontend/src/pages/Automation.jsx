import { useEffect, useState } from "react";
import { Play, Trash2, Plus, Terminal } from "lucide-react";
import HolographicPanel from "../components/Hologram/HolographicPanel";

const API_BASE = (import.meta.env.VITE_API_BASE || "http://localhost:8000").replace(/\/$/, "");

/**
 * Automation control page: launch applications, run whitelisted
 * commands, and manage scheduled cron tasks.
 */
export default function Automation() {
  const [appName, setAppName] = useState("");
  const [command, setCommand] = useState("");
  const [output, setOutput] = useState("");
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState({ name: "", command: "", cron: "0 9 * * *" });

  const refreshTasks = async () => {
    const res = await fetch(`${API_BASE}/api/automation/tasks`);
    const data = await res.json();
    setTasks(data.tasks || []);
  };

  useEffect(() => {
    refreshTasks();
  }, []);

  const handleOpenApp = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API_BASE}/api/automation/open-app`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ app_name: appName }),
    });
    const data = await res.json();
    setOutput(data.output);
  };

  const handleExecute = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API_BASE}/api/automation/execute`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ command }),
    });
    const data = await res.json();
    setOutput(data.output);
  };

  const handleSchedule = async (e) => {
    e.preventDefault();
    await fetch(`${API_BASE}/api/automation/schedule`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newTask),
    });
    setNewTask({ name: "", command: "", cron: "0 9 * * *" });
    refreshTasks();
  };

  const handleDelete = async (id) => {
    await fetch(`${API_BASE}/api/automation/tasks/${id}`, { method: "DELETE" });
    refreshTasks();
  };

  return (
    <div className="grid h-screen grid-cols-1 gap-4 p-6 lg:grid-cols-3">
      <HolographicPanel title="Open Application" icon={<Play size={14} />}>
        <form onSubmit={handleOpenApp} className="space-y-2">
          <input
            value={appName}
            onChange={(e) => setAppName(e.target.value)}
            placeholder="browser, notepad, calculator..."
            className="w-full rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs
              text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
          />
          <button className="w-full rounded-lg border border-cyan-glow/30 bg-cyan-core/10 py-2 text-xs
            font-display uppercase tracking-widest text-cyan-glow hover:bg-cyan-core/20">
            Launch
          </button>
        </form>

        <div className="mt-4">
          <div className="mb-2 flex items-center gap-2 text-xs font-display uppercase tracking-widest text-cyan-glow/70">
            <Terminal size={14} /> Run Command
          </div>
          <form onSubmit={handleExecute} className="space-y-2">
            <input
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder="echo Hello FRIDAY"
              className="w-full rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs font-mono
                text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
            />
            <button className="w-full rounded-lg border border-cyan-glow/30 bg-cyan-core/10 py-2 text-xs
              font-display uppercase tracking-widest text-cyan-glow hover:bg-cyan-core/20">
              Execute
            </button>
          </form>
        </div>

        {output && (
          <pre className="mt-4 max-h-40 overflow-auto rounded border border-cyan-glow/10 bg-void/60 p-3 text-[11px] font-mono text-cyan-glow/80">
            {output}
          </pre>
        )}
      </HolographicPanel>

      <HolographicPanel title="Scheduled Tasks" icon={<Plus size={14} />} className="lg:col-span-2">
        <form onSubmit={handleSchedule} className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-4">
          <input
            value={newTask.name}
            onChange={(e) => setNewTask((t) => ({ ...t, name: e.target.value }))}
            placeholder="Task name"
            className="rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs
              text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
          />
          <input
            value={newTask.command}
            onChange={(e) => setNewTask((t) => ({ ...t, command: e.target.value }))}
            placeholder="Command"
            className="rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs font-mono
              text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
          />
          <input
            value={newTask.cron}
            onChange={(e) => setNewTask((t) => ({ ...t, cron: e.target.value }))}
            placeholder="Cron (0 9 * * *)"
            className="rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs font-mono
              text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
          />
          <button className="rounded-lg border border-cyan-glow/30 bg-cyan-core/10 py-2 text-xs
            font-display uppercase tracking-widest text-cyan-glow hover:bg-cyan-core/20">
            Schedule
          </button>
        </form>

        <div className="space-y-2">
          {tasks.length === 0 && <p className="text-xs text-slate-500 font-body">No scheduled tasks.</p>}
          {tasks.map((t) => (
            <div key={t.id} className="flex items-center justify-between rounded border border-cyan-glow/10 bg-void/40 px-3 py-2 text-xs font-body">
              <div>
                <div className="font-semibold text-slate-100">{t.name}</div>
                <div className="font-mono text-cyan-glow/60">{t.command} — {t.cron}</div>
              </div>
              <button onClick={() => handleDelete(t.id)} className="text-slate-500 hover:text-red-400">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      </HolographicPanel>
    </div>
  );
}
