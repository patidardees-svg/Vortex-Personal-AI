import { useEffect, useState } from "react";
import { Search, User, Clock, Database } from "lucide-react";
import HolographicPanel from "../components/Hologram/HolographicPanel";
import { useFridayStore } from "../store/fridayStore";
import { getUserProfile, semanticSearch, setUserProfileFact } from "../services/memoryService";

/**
 * Memory inspection page: short-term buffer, long-term semantic
 * search, and user profile facts.
 */
export default function Memory() {
  const messages = useFridayStore((s) => s.messages);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [profile, setProfile] = useState({});
  const [newFact, setNewFact] = useState({ key: "", value: "" });

  useEffect(() => {
    getUserProfile().then(setProfile).catch(() => {});
  }, []);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    const data = await semanticSearch(query);
    setResults(data);
  };

  const handleAddFact = async (e) => {
    e.preventDefault();
    if (!newFact.key.trim() || !newFact.value.trim()) return;
    await setUserProfileFact(newFact.key, newFact.value);
    setProfile((p) => ({ ...p, [newFact.key]: newFact.value }));
    setNewFact({ key: "", value: "" });
  };

  return (
    <div className="grid h-screen grid-cols-1 gap-4 p-6 lg:grid-cols-3">
      {/* Short-term memory */}
      <HolographicPanel title="Short-Term Memory" icon={<Clock size={14} />}>
        <div className="space-y-2 text-xs font-body text-slate-300">
          {messages.length === 0 && <p className="text-slate-500">No active conversation yet.</p>}
          {messages.map((m) => (
            <div key={m.id} className="rounded border border-cyan-glow/10 bg-void/40 px-3 py-2">
              <span className="text-cyan-glow/60 uppercase mr-2">{m.role}</span>
              {m.content}
            </div>
          ))}
        </div>
      </HolographicPanel>

      {/* Long-term / semantic search */}
      <HolographicPanel title="Long-Term Memory Search" icon={<Database size={14} />}>
        <form onSubmit={handleSearch} className="mb-3 flex gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search semantic memory..."
            className="flex-1 rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs
              text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
          />
          <button
            type="submit"
            className="flex items-center justify-center rounded-lg border border-cyan-glow/30
              bg-cyan-core/10 px-3 text-cyan-glow hover:bg-cyan-core/20"
          >
            <Search size={14} />
          </button>
        </form>

        <div className="space-y-2 text-xs font-body text-slate-300">
          {results.length === 0 && <p className="text-slate-500">No results yet. Try a search.</p>}
          {results.map((r) => (
            <div key={r.id} className="rounded border border-cyan-glow/10 bg-void/40 px-3 py-2">
              <div className="mb-1 flex justify-between text-[10px] text-cyan-glow/60">
                <span>{r.metadata?.role ?? "memory"}</span>
                <span>{(r.similarity * 100).toFixed(0)}% match</span>
              </div>
              {r.text}
            </div>
          ))}
        </div>
      </HolographicPanel>

      {/* User profile */}
      <HolographicPanel title="User Profile" icon={<User size={14} />}>
        <div className="mb-3 space-y-2 text-xs font-body text-slate-300">
          {Object.keys(profile).length === 0 && <p className="text-slate-500">No profile facts stored.</p>}
          {Object.entries(profile).map(([key, value]) => (
            <div key={key} className="flex justify-between rounded border border-cyan-glow/10 bg-void/40 px-3 py-2">
              <span className="text-cyan-glow/70">{key}</span>
              <span>{value}</span>
            </div>
          ))}
        </div>

        <form onSubmit={handleAddFact} className="space-y-2">
          <input
            value={newFact.key}
            onChange={(e) => setNewFact((f) => ({ ...f, key: e.target.value }))}
            placeholder="Fact key (e.g. favorite_color)"
            className="w-full rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs
              text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
          />
          <input
            value={newFact.value}
            onChange={(e) => setNewFact((f) => ({ ...f, value: e.target.value }))}
            placeholder="Value (e.g. cyan)"
            className="w-full rounded-lg border border-cyan-glow/15 bg-void/60 px-3 py-2 text-xs
              text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50"
          />
          <button
            type="submit"
            className="w-full rounded-lg border border-cyan-glow/30 bg-cyan-core/10 py-2 text-xs
              font-display uppercase tracking-widest text-cyan-glow hover:bg-cyan-core/20"
          >
            Store Fact
          </button>
        </form>
      </HolographicPanel>
    </div>
  );
}
