import { useEffect } from "react";
import NeuralBrain from "../components/Brain/NeuralBrain";
import VoiceWave from "../components/Voice/VoiceWave";
import ChatWindow from "../components/Chat/ChatWindow";
import { useFridayStore } from "../store/fridayStore";
import { useChatSocket } from "../hooks/useChatSocket";
import { useVoice } from "../hooks/useVoice";
import { createConversation } from "../services/aiService";

/**
 * Dedicated full-screen assistant view: larger brain visualization
 * paired with an expanded chat console, for focused conversations.
 */
export default function Assistant() {
  const conversationId = useFridayStore((s) => s.conversationId);
  const setConversationId = useFridayStore((s) => s.setConversationId);

  useEffect(() => {
    if (!conversationId) createConversation().then(setConversationId);
  }, [conversationId]);

  const { sendMessage } = useChatSocket(conversationId);
  const { toggleListening } = useVoice({ onTranscript: sendMessage });

  return (
    <div className="grid h-screen grid-rows-[1fr_auto] gap-4 p-6">
      <div className="relative flex items-center justify-center">
        <div className="relative aspect-square w-full max-w-[720px]">
          <NeuralBrain />
          <VoiceWave />
        </div>
      </div>
      <div className="h-72">
        <ChatWindow onSend={sendMessage} onToggleMic={toggleListening} />
      </div>
    </div>
  );
}
