import { BrowserRouter, Routes, Route } from "react-router-dom";
import { FridayProvider } from "./contexts/FridayContext";

import Home from "./pages/Home";
import Assistant from "./pages/Assistant";
import Memory from "./pages/Memory";
import Settings from "./pages/Settings";
import Automation from "./pages/Automation";

/**
 * Root application component: sets up global providers and routes.
 */
export default function App() {
  return (
    <FridayProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/assistant" element={<Assistant />} />
          <Route path="/memory" element={<Memory />} />
          <Route path="/automation" element={<Automation />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </BrowserRouter>
    </FridayProvider>
  );
}
