import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Sphere, Torus } from "@react-three/drei";
import * as THREE from "three";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Visual effects layer for the brain core:
 * - Inner glowing energy sphere (pulses with brain state)
 * - Wireframe rotating rings (HUD-style orbital rings)
 * - Outer glow sphere for bloom effect
 */
export default function BrainEffects() {
  const coreRef = useRef();
  const ring1Ref = useRef();
  const ring2Ref = useRef();
  const glowRef = useRef();

  const brainState = useFridayStore((s) => s.brainState);
  const micAmplitude = useFridayStore((s) => s.micAmplitude);

  const stateColor = {
    idle: "#00d4ff",
    listening: "#5ef3ff",
    thinking: "#7a5cff",
    speaking: "#5ef3ff",
    alert: "#ff8a3d",
  };

  const stateIntensity = {
    idle: 1,
    listening: 1.4,
    thinking: 2.2,
    speaking: 1.8,
    alert: 2.6,
  };

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    const intensity = (stateIntensity[brainState] ?? 1) + micAmplitude * 2;

    if (coreRef.current) {
      const pulse = 1 + Math.sin(t * 2 * intensity) * 0.08 * intensity;
      coreRef.current.scale.setScalar(pulse);
      coreRef.current.material.emissiveIntensity = 0.6 + Math.sin(t * 3) * 0.2 * intensity;
    }

    if (glowRef.current) {
      const glowPulse = 1 + Math.sin(t * 1.5) * 0.05 * intensity;
      glowRef.current.scale.setScalar(glowPulse * 1.6);
      glowRef.current.material.opacity = 0.08 + Math.sin(t * 2) * 0.03 * intensity;
    }

    if (ring1Ref.current) {
      ring1Ref.current.rotation.x = t * 0.3;
      ring1Ref.current.rotation.y = t * 0.15;
    }
    if (ring2Ref.current) {
      ring2Ref.current.rotation.x = -t * 0.2;
      ring2Ref.current.rotation.z = t * 0.25;
    }
  });

  const color = stateColor[brainState] ?? "#00d4ff";

  return (
    <group>
      {/* Inner energy core */}
      <Sphere ref={coreRef} args={[0.9, 64, 64]}>
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={0.8}
          roughness={0.2}
          metalness={0.6}
          transparent
          opacity={0.85}
        />
      </Sphere>

      {/* Outer glow sphere (additive, large, for bloom) */}
      <Sphere ref={glowRef} args={[1.4, 32, 32]}>
        <meshBasicMaterial color={color} transparent opacity={0.1} depthWrite={false} blending={THREE.AdditiveBlending} />
      </Sphere>

      {/* HUD orbital rings */}
      <Torus ref={ring1Ref} args={[2.1, 0.008, 16, 100]}>
        <meshBasicMaterial color="#5ef3ff" transparent opacity={0.35} />
      </Torus>
      <Torus ref={ring2Ref} args={[2.35, 0.006, 16, 100]} rotation={[Math.PI / 3, 0, 0]}>
        <meshBasicMaterial color="#00d4ff" transparent opacity={0.25} />
      </Torus>
    </group>
  );
}
