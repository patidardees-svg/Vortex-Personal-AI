import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFridayStore } from "../../store/fridayStore";

/**
 * GPU-optimized particle system forming a spherical "neural cloud".
 * Uses a single BufferGeometry + Points mesh (one draw call) for
 * thousands of particles. Reacts to brain state (idle/thinking/speaking)
 * and microphone amplitude.
 */
export default function ParticleSystem({ count = 6000, radius = 2.6 }) {
  const pointsRef = useRef();
  const brainState = useFridayStore((s) => s.brainState);
  const micAmplitude = useFridayStore((s) => s.micAmplitude);

  // Pre-compute particle positions on a fuzzy sphere shell + velocities
  const { positions, basePositions, speeds } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const basePositions = new Float32Array(count * 3);
    const speeds = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      // Distribute points across a noisy sphere shell
      const r = radius * (0.65 + Math.random() * 0.45);
      const theta = Math.acos(2 * Math.random() - 1);
      const phi = Math.random() * Math.PI * 2;

      const x = r * Math.sin(theta) * Math.cos(phi);
      const y = r * Math.sin(theta) * Math.sin(phi);
      const z = r * Math.cos(theta);

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      basePositions[i * 3] = x;
      basePositions[i * 3 + 1] = y;
      basePositions[i * 3 + 2] = z;

      speeds[i] = 0.4 + Math.random() * 1.2;
    }

    return { positions, basePositions, speeds };
  }, [count, radius]);

  const colorAttr = useMemo(() => {
    const colors = new Float32Array(count * 3);
    const cyan = new THREE.Color("#5ef3ff");
    const blue = new THREE.Color("#0091b3");

    for (let i = 0; i < count; i++) {
      const mix = Math.random();
      const c = cyan.clone().lerp(blue, mix);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    return colors;
  }, [count]);

  // Intensity multiplier per brain state — drives pulse speed & amplitude
  const stateIntensity = {
    idle: 0.25,
    listening: 0.6,
    thinking: 1.2,
    speaking: 1.0,
    alert: 1.6,
  };

  useFrame(({ clock }) => {
    if (!pointsRef.current) return;
    const t = clock.getElapsedTime();
    const intensity = (stateIntensity[brainState] ?? 0.25) + micAmplitude * 1.5;

    const posAttr = pointsRef.current.geometry.attributes.position;

    for (let i = 0; i < count; i++) {
      const idx = i * 3;
      const bx = basePositions[idx];
      const by = basePositions[idx + 1];
      const bz = basePositions[idx + 2];

      // Radial pulse based on noise-like sine combination
      const pulse =
        1 +
        Math.sin(t * speeds[i] * intensity + i * 0.05) * 0.06 * intensity;

      posAttr.array[idx] = bx * pulse;
      posAttr.array[idx + 1] = by * pulse;
      posAttr.array[idx + 2] = bz * pulse;
    }

    posAttr.needsUpdate = true;

    // Slow ambient rotation, faster when thinking
    pointsRef.current.rotation.y = t * (0.05 + intensity * 0.05);
    pointsRef.current.rotation.x = Math.sin(t * 0.1) * 0.1;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
        <bufferAttribute attach="attributes-color" count={count} array={colorAttr} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial
        size={0.02}
        vertexColors
        transparent
        opacity={0.85}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        sizeAttenuation
      />
    </points>
  );
}
