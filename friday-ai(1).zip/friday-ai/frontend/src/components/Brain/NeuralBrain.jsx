import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { EffectComposer, Bloom, Vignette } from "@react-three/postprocessing";
import { OrbitControls, PerspectiveCamera } from "@react-three/drei";

import ParticleSystem from "./ParticleSystem";
import SynapseLines from "./SynapseLines";
import BrainEffects from "./BrainEffects";

/**
 * Central animated neural brain — the visual centerpiece of FRIDAY.
 * Combines a particle cloud, animated synapse connections, and an
 * energy core, with bloom post-processing for a glowing HUD look.
 *
 * GPU notes:
 * - Particle system uses a single Points draw call for 6000 particles.
 * - Synapse lines are capped at 60 segments for performance.
 * - Bloom intensity is moderate to keep frame times low on integrated GPUs.
 */
export default function NeuralBrain() {
  return (
    <Canvas
      dpr={[1, 1.5]}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      style={{ width: "100%", height: "100%" }}
    >
      <PerspectiveCamera makeDefault position={[0, 0, 6.5]} fov={45} />
      <ambientLight intensity={0.3} />
      <pointLight position={[5, 5, 5]} intensity={1.2} color="#5ef3ff" />
      <pointLight position={[-5, -3, -5]} intensity={0.6} color="#7a5cff" />

      <Suspense fallback={null}>
        <BrainEffects />
        <ParticleSystem count={6000} radius={2.6} />
        <SynapseLines count={50} radius={2.6} />
      </Suspense>

      <EffectComposer disableNormalPass>
        <Bloom intensity={1.1} luminanceThreshold={0.15} luminanceSmoothing={0.9} mipmapBlur />
        <Vignette eskil={false} offset={0.2} darkness={0.9} />
      </EffectComposer>

      <OrbitControls
        enablePan={false}
        enableZoom={false}
        autoRotate
        autoRotateSpeed={0.4}
        maxPolarAngle={Math.PI / 1.6}
        minPolarAngle={Math.PI / 3}
      />
    </Canvas>
  );
}
