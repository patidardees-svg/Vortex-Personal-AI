import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Animated synapse connections: a set of line segments between
 * random points on the brain sphere, with a traveling energy pulse
 * along each line (rendered as a moving emissive sphere).
 */
export default function SynapseLines({ count = 60, radius = 2.6 }) {
  const brainState = useFridayStore((s) => s.brainState);
  const groupRef = useRef();
  const pulsesRef = useRef([]);

  const lines = useMemo(() => {
    const segments = [];
    for (let i = 0; i < count; i++) {
      const a = randomPointOnSphere(radius * 0.9);
      const b = randomPointOnSphere(radius * 0.9);
      segments.push({ a, b, offset: Math.random(), speed: 0.3 + Math.random() * 0.7 });
    }
    return segments;
  }, [count, radius]);

  const speedMultiplier = {
    idle: 0.5,
    listening: 1.2,
    thinking: 2.4,
    speaking: 1.8,
    alert: 3,
  };

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    const mult = speedMultiplier[brainState] ?? 0.5;

    pulsesRef.current.forEach((mesh, i) => {
      if (!mesh) return;
      const { a, b, offset, speed } = lines[i];
      const progress = (t * speed * mult + offset) % 1;

      mesh.position.set(
        THREE.MathUtils.lerp(a[0], b[0], progress),
        THREE.MathUtils.lerp(a[1], b[1], progress),
        THREE.MathUtils.lerp(a[2], b[2], progress)
      );

      const scale = 0.5 + Math.sin(progress * Math.PI) * 0.8;
      mesh.scale.setScalar(scale * 0.04);
    });

    if (groupRef.current) {
      groupRef.current.rotation.y = t * 0.04;
    }
  });

  return (
    <group ref={groupRef}>
      {lines.map((line, i) => (
        <line key={i}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={2}
              array={new Float32Array([...line.a, ...line.b])}
              itemSize={3}
            />
          </bufferGeometry>
          <lineBasicMaterial color="#00d4ff" transparent opacity={0.12} />
        </line>
      ))}

      {lines.map((_, i) => (
        <mesh key={`pulse-${i}`} ref={(el) => (pulsesRef.current[i] = el)}>
          <sphereGeometry args={[1, 6, 6]} />
          <meshBasicMaterial color="#5ef3ff" toneMapped={false} />
        </mesh>
      ))}
    </group>
  );
}

function randomPointOnSphere(radius) {
  const theta = Math.acos(2 * Math.random() - 1);
  const phi = Math.random() * Math.PI * 2;
  return [
    radius * Math.sin(theta) * Math.cos(phi),
    radius * Math.sin(theta) * Math.sin(phi),
    radius * Math.cos(theta),
  ];
}
