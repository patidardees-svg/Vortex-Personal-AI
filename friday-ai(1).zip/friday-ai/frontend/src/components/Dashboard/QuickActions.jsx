import { Globe, Terminal, FolderOpen, Calculator } from "lucide-react";
import { useFridayStore } from "../../store/fridayStore";

const ACTIONS = [
  { label: "Browser", icon: <Globe size={16} />, command: "open browser" },
  { label: "Files", icon: <FolderOpen size={16} />, command: "open explorer" },
  { label: "Calculator", icon: <Calculator size={16} />, command: "open calculator" },
  { label: "System Status", icon: <Terminal size={16} />, command: "system status" },
];

/**
 * Quick action buttons that send pre-built automation commands
 * to FRIDAY via the chat pipeline (open app / system status / etc).
 */
export default function QuickActions({ onSend }) {
  const isStreaming = useFridayStore((s) => s.isStreaming);

  return (
    <div className="grid grid-cols-2 gap-2">
      {ACTIONS.map((action) => (
        <button
          key={action.label}
          disabled={isStreaming}
          onClick={() => onSend(action.command)}
          className="flex flex-col items-center gap-1.5 rounded-lg border border-cyan-glow/10
            bg-void/40 px-3 py-3 text-xs font-body text-slate-300 transition-all
            hover:border-cyan-glow/40 hover:bg-cyan-core/10 hover:text-cyan-glow
            disabled:cursor-not-allowed disabled:opacity-40"
        >
          {action.icon}
          {action.label}
        </button>
      ))}
    </div>
  );
}
