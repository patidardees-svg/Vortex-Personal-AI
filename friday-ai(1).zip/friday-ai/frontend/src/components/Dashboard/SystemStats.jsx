import { Cpu, MemoryStick, Activity, Wifi } from "lucide-react";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Live system stats bars: CPU, RAM, GPU, Network — driven by the
 * system stats WebSocket feed in the global store.
 */
export default function SystemStats() {
  const stats = useFridayStore((s) => s.systemStats);

  const gpu = stats.gpu?.[0];

  const rows = [
    { label: "CPU", value: stats.cpu ?? 0, icon: <Cpu size={14} />, unit: "%" },
    { label: "RAM", value: stats.ram?.percent ?? 0, icon: <MemoryStick size={14} />, unit: "%" },
    { label: "GPU", value: gpu?.load ?? 0, icon: <Activity size={14} />, unit: "%" },
    { label: "NET", value: networkLoad(stats.network), icon: <Wifi size={14} />, unit: "%" },
  ];

  return (
    <div className="space-y-3">
      {rows.map((row) => (
        <div key={row.label}>
          <div className="mb-1 flex items-center justify-between text-xs font-body text-slate-300">
            <span className="flex items-center gap-1.5 text-cyan-glow/80">
              {row.icon}
              {row.label}
            </span>
            <span className="font-mono">{row.value.toFixed(0)}{row.unit}</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-void/60">
            <div
              className="h-full rounded-full bg-gradient-to-r from-cyan-deep to-cyan-glow shadow-glow-cyan transition-all duration-700"
              style={{ width: `${Math.min(100, row.value)}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

// Approximate a 0-100 "load" value from network throughput for display purposes
function networkLoad(network) {
  if (!network) return 0;
  const total = (network.sent + network.recv) / 1_000_000;
  return Math.min(100, total % 100);
}
