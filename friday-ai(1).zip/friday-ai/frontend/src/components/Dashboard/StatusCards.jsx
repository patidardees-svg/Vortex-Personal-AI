import { motion, AnimatePresence } from "framer-motion";
import { Bell, AlertTriangle, Info, CheckCircle2, X } from "lucide-react";
import { useFridayStore } from "../../store/fridayStore";

const ICONS = {
  info: <Info size={14} className="text-cyan-glow" />,
  warning: <AlertTriangle size={14} className="text-amber-alert" />,
  error: <AlertTriangle size={14} className="text-red-400" />,
  success: <CheckCircle2 size={14} className="text-emerald-400" />,
};

/**
 * Notification feed: displays system/AI notifications pushed into
 * the global store (wake-word events, errors, task completions).
 */
export default function StatusCards() {
  const notifications = useFridayStore((s) => s.notifications);
  const dismissNotification = useFridayStore((s) => s.dismissNotification);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-xs font-display uppercase tracking-widest text-cyan-glow/70">
        <Bell size={14} />
        Notifications
      </div>

      <div className="max-h-48 space-y-2 overflow-y-auto pr-1">
        <AnimatePresence>
          {notifications.length === 0 && (
            <div className="py-4 text-center text-xs text-slate-500 font-body">
              No active alerts. All systems nominal.
            </div>
          )}

          {notifications.map((n) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="flex items-start gap-2 rounded-lg border border-cyan-glow/10 bg-void/40 px-3 py-2"
            >
              <div className="mt-0.5">{ICONS[n.type] ?? ICONS.info}</div>
              <div className="flex-1">
                <div className="text-xs font-semibold text-slate-100">{n.title}</div>
                <div className="text-[11px] text-slate-400">{n.message}</div>
              </div>
              <button
                onClick={() => dismissNotification(n.id)}
                className="text-slate-500 hover:text-cyan-glow"
                aria-label="Dismiss notification"
              >
                <X size={12} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
