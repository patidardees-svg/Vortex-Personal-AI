import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Abstract humanoid energy figure — NOT a literal/anatomical body.
 * Built from particles distributed along a simplified humanoid silhouette
 * (head/torso/arm/leg "volumes"), rendered as glowing points plus a few
 * vertical energy strands. Reacts to brainState the same way the neural
 * brain core does: idle = slow ambient drift, listening/thinking = denser,
 * faster, brighter, with a subtle forward "thinking" lean.
 *
 * Designed to sit in its own small Canvas (see HumanHologramView) inside
 * the System Status side panel.
 */

// Approximate humanoid silhouette as a set of capsule-like volumes.
// Each entry: { center: [x,y,z], radius, height (along Y), axis spread, density weight }
const BODY_VOLUMES = [
  { center: [0, 1.62, 0], rx: 0.16, ry: 0.2, rz: 0.16, weight: 0.12 }, // head
  { center: [0, 1.18, 0], rx: 0.24, ry: 0.34, rz: 0.16, weight: 0.22 }, // chest/torso
  { center: [0, 0.78, 0], rx: 0.2, ry: 0.22, rz: 0.14, weight: 0.14 }, // pelvis
  { center: [-0.32, 1.3, 0], rx: 0.08, ry: 0.22, rz: 0.08, weight: 0.08 }, // L upper arm
  { center: [0.32, 1.3, 0], rx: 0.08, ry: 0.22, rz: 0.08, weight: 0.08 }, // R upper arm
  { center: [-0.42, 0.92, 0], rx: 0.06, ry: 0.2, rz: 0.06, weight: 0.06 }, // L forearm
  { center: [0.42, 0.92, 0], rx: 0.06, ry: 0.2, rz: 0.06, weight: 0.06 }, // R forearm
  { center: [-0.13, 0.42, 0], rx: 0.09, ry: 0.36, rz: 0.1, weight: 0.12 }, // L thigh
  { center: [0.13, 0.42, 0], rx: 0.09, ry: 0.36, rz: 0.1, weight: 0.12 }, // R thigh
  { center: [-0.13, -0.02, 0], rx: 0.07, ry: 0.34, rz: 0.08, weight: 0.1 }, // L shin
  { center: [0.13, -0.02, 0], rx: 0.07, ry: 0.34, rz: 0.08, weight: 0.1 }, // R shin
];

function sampleInVolume(vol) {
  // Gaussian-ish jitter within an ellipsoid for a soft, energy-like cloud
  const u = Math.random() * Math.PI * 2;
  const v = Math.acos(2 * Math.random() - 1);
  const r = Math.pow(Math.random(), 0.4); // bias toward surface, not just center
  const x = r * Math.sin(v) * Math.cos(u) * vol.rx;
  const y = r * Math.sin(v) * Math.sin(u) * vol.ry;
  const z = r * Math.cos(v) * vol.rz;
  return [vol.center[0] + x, vol.center[1] + y, vol.center[2] + z];
}

export default function HumanHologram({ count = 1400 }) {
  const pointsRef = useRef();
  const strandsRef = useRef();
  const groupRef = useRef();

  const brainState = useFridayStore((s) => s.brainState);

  const totalWeight = useMemo(
    () => BODY_VOLUMES.reduce((sum, v) => sum + v.weight, 0),
    []
  );

  const { positions, basePositions, seeds } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const basePositions = new Float32Array(count * 3);
    const seeds = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      // Pick a volume weighted by its share of total body mass
      let r = Math.random() * totalWeight;
      let chosen = BODY_VOLUMES[0];
      for (const vol of BODY_VOLUMES) {
        if (r < vol.weight) {
          chosen = vol;
          break;
        }
        r -= vol.weight;
      }
      const [x, y, z] = sampleInVolume(chosen);
      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;
      basePositions[i * 3] = x;
      basePositions[i * 3 + 1] = y;
      basePositions[i * 3 + 2] = z;
      seeds[i] = Math.random() * Math.PI * 2;
    }
    return { positions, basePositions, seeds };
  }, [count, totalWeight]);

  // A handful of vertical "energy strand" lines running through the figure,
  // echoing the brain's synapse-line language at a smaller scale.
  const strands = useMemo(() => {
    const lines = [];
    for (let i = 0; i < 14; i++) {
      const xOff = (Math.random() - 0.5) * 0.5;
      const zOff = (Math.random() - 0.5) * 0.2;
      const yStart = -0.45 + Math.random() * 0.2;
      const yEnd = 1.6 + Math.random() * 0.15;
      lines.push({ xOff, zOff, yStart, yEnd, speed: 0.3 + Math.random() * 0.6, offset: Math.random() });
    }
    return lines;
  }, []);

  const stateIntensity = {
    idle: 0.3,
    listening: 0.7,
    thinking: 1.3,
    speaking: 1.0,
    alert: 1.6,
  };

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    const intensity = stateIntensity[brainState] ?? 0.3;
    const thinking = brainState === "thinking" || brainState === "alert";

    // Slow ambient rotation, plus a subtle forward lean when "thinking"
    if (groupRef.current) {
      groupRef.current.rotation.y = t * (0.08 + intensity * 0.05);
      const targetTiltX = thinking ? -0.12 : 0;
      groupRef.current.rotation.x += (targetTiltX - groupRef.current.rotation.x) * 0.04;
      const breathe = Math.sin(t * 1.1) * 0.015;
      groupRef.current.position.y = breathe;
    }

    // Particle jitter/pulse driven by brain state
    if (pointsRef.current) {
      const posAttr = pointsRef.current.geometry.attributes.position;
      for (let i = 0; i < count; i++) {
        const idx = i * 3;
        const bx = basePositions[idx];
        const by = basePositions[idx + 1];
        const bz = basePositions[idx + 2];
        const seed = seeds[i];

        const jitter = (0.004 + intensity * 0.01) * Math.sin(t * (1 + intensity) + seed);
        posAttr.array[idx] = bx + jitter;
        posAttr.array[idx + 1] = by + jitter * 0.6;
        posAttr.array[idx + 2] = bz + jitter;
      }
      posAttr.needsUpdate = true;
      pointsRef.current.material.size = 0.012 + intensity * 0.006;
      pointsRef.current.material.opacity = 0.55 + intensity * 0.25;
    }

    // Strand pulses traveling upward through the figure
    if (strandsRef.current) {
      strandsRef.current.children.forEach((line, i) => {
        const s = strands[i];
        const mat = line.material;
        const progress = (t * s.speed * (0.6 + intensity) + s.offset) % 1;
        mat.opacity = 0.08 + 0.18 * intensity * (1 - Math.abs(progress - 0.5) * 2);
      });
    }
  });

  const color = brainState === "alert" ? "#ff8a3d" : "#5ef3ff";

  return (
    <group ref={groupRef} position={[0, -0.85, 0]}>
      {/* Particle cloud forming the humanoid silhouette */}
      <points ref={pointsRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
        </bufferGeometry>
        <pointsMaterial
          color={color}
          size={0.015}
          transparent
          opacity={0.7}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          sizeAttenuation
        />
      </points>

      {/* Faint vertical energy strands */}
      <group ref={strandsRef}>
        {strands.map((s, i) => (
          <line key={i}>
            <bufferGeometry>
              <bufferAttribute
                attach="attributes-position"
                count={2}
                array={new Float32Array([s.xOff, s.yStart, s.zOff, s.xOff, s.yEnd, s.zOff])}
                itemSize={3}
              />
            </bufferGeometry>
            <lineBasicMaterial color={color} transparent opacity={0.12} />
          </line>
        ))}
      </group>

      {/* Soft ground glow disc, like a holographic projector base */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.46, 0]}>
        <circleGeometry args={[0.55, 32]} />
        <meshBasicMaterial color={color} transparent opacity={0.05} depthWrite={false} blending={THREE.AdditiveBlending} />
      </mesh>
    </group>
  );
}
