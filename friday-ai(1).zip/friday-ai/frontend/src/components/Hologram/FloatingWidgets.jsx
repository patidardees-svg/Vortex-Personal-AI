import { motion } from "framer-motion";

const WIDGETS = [
  { label: "CORE TEMP", value: "42°C", top: "12%", left: "8%" },
  { label: "UPLINK", value: "STABLE", top: "78%", left: "6%" },
  { label: "SECURITY", value: "ACTIVE", top: "16%", left: "88%" },
  { label: "PROTOCOL", value: "V4.2", top: "82%", left: "90%" },
];

/**
 * Small ambient floating HUD readouts scattered around the screen edges,
 * for atmosphere (purely decorative telemetry).
 */
export default function FloatingWidgets() {
  return (
    <div className="pointer-events-none absolute inset-0 hidden lg:block">
      {WIDGETS.map((w, i) => (
        <motion.div
          key={w.label}
          className="absolute font-mono text-[10px] uppercase tracking-widest text-cyan-glow/40"
          style={{ top: w.top, left: w.left }}
          animate={{ opacity: [0.3, 0.7, 0.3], y: [0, -4, 0] }}
          transition={{ duration: 4 + i, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="border-l border-cyan-glow/30 pl-2">
            <div>{w.label}</div>
            <div className="text-cyan-glow/70">{w.value}</div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
