import { motion } from "framer-motion";

/**
 * Reusable holographic glass panel with HUD corner brackets,
 * a title bar, and entry animation. Used for all side widgets.
 */
export default function HolographicPanel({ title, icon, children, className = "" }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4 }}
      className={`glass-panel flex flex-col overflow-hidden ${className}`}
    >
      <div className="hud-corner tl" />
      <div className="hud-corner tr" />
      <div className="hud-corner bl" />
      <div className="hud-corner br" />

      {title && (
        <div className="flex items-center gap-2 border-b border-cyan-glow/10 px-4 py-2">
          {icon}
          <span className="font-display text-xs uppercase tracking-[0.2em] text-cyan-glow/80">
            {title}
          </span>
        </div>
      )}
      <div className="flex-1 px-4 py-3">{children}</div>
    </motion.div>
  );
}
