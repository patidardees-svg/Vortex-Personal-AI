import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { PerspectiveCamera } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";

import HumanHologram from "./HumanHologram";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Self-contained Canvas wrapper for the abstract human energy hologram,
 * sized to drop into the System Status side panel beneath the stat bars.
 * Includes a HUD caption that tracks brainState (STANDBY / LISTENING / THINKING).
 */
export default function HumanHologramView() {
  const brainState = useFridayStore((s) => s.brainState);

  const captionMap = {
    idle: "STANDBY",
    listening: "LISTENING",
    thinking: "THINKING",
    speaking: "RESPONDING",
    alert: "ALERT",
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="h-48 w-full">
        <Canvas
          dpr={[1, 1.5]}
          gl={{ antialias: true, alpha: true }}
          style={{ width: "100%", height: "100%" }}
        >
          <PerspectiveCamera makeDefault position={[0, 0.2, 2.4]} fov={40} />
          <ambientLight intensity={0.4} />

          <Suspense fallback={null}>
            <HumanHologram count={1400} />
          </Suspense>

          <EffectComposer disableNormalPass>
            <Bloom intensity={0.9} luminanceThreshold={0.1} luminanceSmoothing={0.85} mipmapBlur />
          </EffectComposer>
        </Canvas>
      </div>
      <div className="font-mono text-[9px] uppercase tracking-[0.2em] text-cyan-glow/50">
        USER PROFILE // {captionMap[brainState] ?? "STANDBY"}
      </div>
    </div>
  );
}
