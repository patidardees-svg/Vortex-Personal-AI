import { motion } from "framer-motion";

/**
 * Single chat message bubble. User messages align right with a
 * solid panel; FRIDAY responses align left with a glowing cyan accent.
 */
export default function MessageBubble({ role, content }) {
  const isUser = role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex ${isUser ? "justify-end" : "justify-start"}`}
    >
      <div
        className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm leading-relaxed font-body
          ${isUser
            ? "bg-cyan-core/10 border border-cyan-core/30 text-cyan-glow"
            : "bg-panel/70 border border-cyan-glow/15 text-slate-100"}`}
      >
        {!isUser && (
          <div className="mb-1 text-[10px] font-display uppercase tracking-widest text-cyan-glow/70">
            FRIDAY
          </div>
        )}
        <p className="whitespace-pre-wrap">{content || "\u00A0"}</p>
      </div>
    </motion.div>
  );
}
