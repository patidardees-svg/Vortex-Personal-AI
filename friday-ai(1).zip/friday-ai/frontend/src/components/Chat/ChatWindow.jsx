import { useEffect, useRef, useState } from "react";
import { Send } from "lucide-react";
import { useFridayStore } from "../../store/fridayStore";
import MessageBubble from "./MessageBubble";
import TypingIndicator from "./TypingIndicator";
import MicButton from "../Voice/MicButton";
import VoiceVisualizer from "../Voice/VoiceVisualizer";

/**
 * Bottom chat console: message history, streaming responses,
 * typing indicator, text input, and mic control.
 */
export default function ChatWindow({ onSend, onToggleMic }) {
  const messages = useFridayStore((s) => s.messages);
  const isStreaming = useFridayStore((s) => s.isStreaming);
  const [input, setInput] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    onSend(input.trim());
    setInput("");
  };

  return (
    <div className="glass-panel flex h-full flex-col overflow-hidden">
      <div className="hud-corner tl" />
      <div className="hud-corner tr" />

      {/* Header */}
      <div className="flex items-center justify-between border-b border-cyan-glow/10 px-4 py-2">
        <span className="font-display text-xs uppercase tracking-[0.2em] text-cyan-glow/80">
          Comm Channel
        </span>
        <div className="h-20 w-40 opacity-70">
          <VoiceVisualizer />
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-3">
        {messages.length === 0 && (
          <div className="flex h-full items-center justify-center text-center text-sm text-slate-400/60 font-body">
            Say <span className="text-cyan-glow mx-1">"Friday"</span> or type a command to begin.
          </div>
        )}
        {messages.map((m) => (
          <MessageBubble key={m.id} role={m.role} content={m.content} />
        ))}
        {isStreaming && messages[messages.length - 1]?.content === "" && <TypingIndicator />}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="flex items-center gap-3 border-t border-cyan-glow/10 px-4 py-3">
        <MicButton onClick={onToggleMic} />
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Transmit a command to FRIDAY..."
          className="flex-1 rounded-lg border border-cyan-glow/15 bg-void/60 px-4 py-3 text-sm font-body
            text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-glow/50
            focus:shadow-glow-cyan transition-shadow"
        />
        <button
          type="submit"
          className="flex h-12 w-12 items-center justify-center rounded-lg border border-cyan-glow/30
            bg-cyan-core/10 text-cyan-glow hover:bg-cyan-core/20 hover:shadow-glow-cyan transition-all"
          aria-label="Send message"
        >
          <Send size={18} />
        </button>
      </form>
    </div>
  );
}
