import { Mic, MicOff } from "lucide-react";
import { motion } from "framer-motion";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Primary mic toggle button. Glows and pulses while listening.
 */
export default function MicButton({ onClick }) {
  const isListening = useFridayStore((s) => s.isListening);

  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.92 }}
      className={`relative flex h-14 w-14 items-center justify-center rounded-full border transition-colors
        ${isListening
          ? "border-cyan-glow bg-cyan-core/20 shadow-glow-cyan-lg"
          : "border-cyan-glow/30 bg-panel/60 hover:border-cyan-glow/60"}`}
      aria-label={isListening ? "Stop listening" : "Start listening"}
    >
      {isListening && (
        <motion.span
          className="absolute inset-0 rounded-full border border-cyan-glow"
          animate={{ scale: [1, 1.6], opacity: [0.6, 0] }}
          transition={{ duration: 1.4, repeat: Infinity, ease: "easeOut" }}
        />
      )}
      {isListening ? (
        <Mic size={22} className="text-cyan-glow text-glow" />
      ) : (
        <MicOff size={22} className="text-cyan-glow/60" />
      )}
    </motion.button>
  );
}
