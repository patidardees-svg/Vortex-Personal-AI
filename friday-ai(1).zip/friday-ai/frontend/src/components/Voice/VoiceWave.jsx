import { motion } from "framer-motion";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Circular "voice ring" overlay positioned around the brain core.
 * Expands and pulses based on mic amplitude / brain state.
 */
export default function VoiceWave() {
  const brainState = useFridayStore((s) => s.brainState);
  const micAmplitude = useFridayStore((s) => s.micAmplitude);

  const ringCount = 3;
  const active = ["listening", "speaking", "thinking"].includes(brainState);

  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
      {Array.from({ length: ringCount }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full border border-cyan-glow/40"
          style={{
            width: `${60 + i * 14}%`,
            height: `${60 + i * 14}%`,
          }}
          animate={
            active
              ? {
                  scale: [1, 1.04 + micAmplitude * 0.15, 1],
                  opacity: [0.15, 0.45, 0.15],
                }
              : { scale: 1, opacity: 0.08 }
          }
          transition={{
            duration: 2.4 - i * 0.4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}
