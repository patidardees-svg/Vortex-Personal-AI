import { useEffect, useRef } from "react";
import { useFridayStore } from "../../store/fridayStore";

/**
 * Real-time waveform visualizer rendered on a canvas, driven by
 * mic amplitude from the global store. Renders a JARVIS-style
 * vertical bar equalizer.
 */
export default function VoiceVisualizer({ barCount = 32, height = 48 }) {
  const canvasRef = useRef(null);
  const historyRef = useRef(new Array(barCount).fill(0));
  const rafRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    const render = () => {
      const amplitude = useFridayStore.getState().micAmplitude;
      const brainState = useFridayStore.getState().brainState;
      const isActive = brainState === "listening" || brainState === "speaking";

      const history = historyRef.current;
      history.shift();
      const base = isActive ? amplitude : 0.05;
      const jitter = isActive ? Math.random() * 0.3 : Math.random() * 0.04;
      history.push(Math.min(1, base + jitter));

      const { width } = canvas;
      ctx.clearRect(0, 0, width, height);

      const barWidth = width / barCount;
      history.forEach((val, i) => {
        const barHeight = Math.max(2, val * height);
        const x = i * barWidth;
        const y = (height - barHeight) / 2;

        const gradient = ctx.createLinearGradient(0, y, 0, y + barHeight);
        gradient.addColorStop(0, "#5ef3ff");
        gradient.addColorStop(1, "#0091b3");

        ctx.fillStyle = gradient;
        ctx.shadowColor = "#5ef3ff";
        ctx.shadowBlur = 6;
        ctx.fillRect(x + 1, y, barWidth - 2, barHeight);
      });

      rafRef.current = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(rafRef.current);
  }, [barCount, height]);

  return <canvas ref={canvasRef} width={240} height={height} className="w-full h-full" />;
}
