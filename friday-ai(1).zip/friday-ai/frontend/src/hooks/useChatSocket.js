import { useEffect, useRef } from "react";
import { ChatSocket } from "../services/websocket";
import { useFridayStore } from "../store/fridayStore";

/**
 * Manages the chat WebSocket lifecycle and wires incoming events
 * into the global FRIDAY store (streaming tokens, brain state, stats).
 */
export function useChatSocket(conversationId) {
  const socketRef = useRef(null);

  const appendToLastMessage = useFridayStore((s) => s.appendToLastMessage);
  const addMessage = useFridayStore((s) => s.addMessage);
  const setStreaming = useFridayStore((s) => s.setStreaming);
  const setBrainState = useFridayStore((s) => s.setBrainState);
  const setSystemStats = useFridayStore((s) => s.setSystemStats);
  const pushNotification = useFridayStore((s) => s.pushNotification);

  useEffect(() => {
    if (!conversationId) return;

    const socket = new ChatSocket(conversationId);
    socketRef.current = socket;
    socket.connect();

    const unsubscribe = socket.subscribe((event) => {
      switch (event.type) {
        case "status":
          if (event.data === "thinking") setBrainState("thinking");
          if (event.data === "executing_tool") setBrainState("thinking");
          break;

        case "token":
          appendToLastMessage(event.data);
          break;

        case "system_stats":
          setSystemStats(event.data);
          break;

        case "done":
          setStreaming(false);
          setBrainState("speaking");
          setTimeout(() => setBrainState("idle"), 2200);
          break;

        case "error":
          pushNotification({ type: "error", title: "FRIDAY Error", message: event.data });
          setStreaming(false);
          setBrainState("idle");
          break;

        default:
          break;
      }
    });

    return () => {
      unsubscribe();
      socket.disconnect();
    };
  }, [conversationId]);

  const sendMessage = (text) => {
    if (!socketRef.current) return;

    addMessage({ role: "user", content: text, id: crypto.randomUUID() });
    addMessage({ role: "assistant", content: "", id: crypto.randomUUID() });
    setStreaming(true);
    setBrainState("thinking");

    socketRef.current.send(text);
  };

  return { sendMessage };
}
