import { useEffect, useRef } from "react";
import { VoiceController } from "../services/voiceService";
import { useFridayStore } from "../store/fridayStore";

/**
 * Wires the VoiceController (STT, wake-word, TTS, amplitude) into
 * the global FRIDAY store and exposes simple controls for the UI.
 */
export function useVoice({ onTranscript } = {}) {
  const controllerRef = useRef(null);

  const setListening = useFridayStore((s) => s.setListening);
  const setMicAmplitude = useFridayStore((s) => s.setMicAmplitude);
  const setBrainState = useFridayStore((s) => s.setBrainState);
  const pushNotification = useFridayStore((s) => s.pushNotification);

  useEffect(() => {
    controllerRef.current = new VoiceController({
      onResult: (transcript) => {
        onTranscript?.(transcript);
      },
      onWakeWord: () => {
        setBrainState("listening");
        pushNotification({ type: "info", title: "Wake word detected", message: '"Friday" heard — listening...' });
      },
      onAmplitude: (amp) => setMicAmplitude(amp),
      onListeningChange: (val) => setListening(val),
    });

    return () => controllerRef.current?.stopListening();
  }, []);

  const toggleListening = () => {
    const ctrl = controllerRef.current;
    const isListening = useFridayStore.getState().isListening;
    if (isListening) {
      ctrl.stopListening();
      setBrainState("idle");
    } else {
      ctrl.startListening();
      setBrainState("listening");
    }
  };

  const speak = (text) => {
    controllerRef.current?.speak(text, {
      onStart: () => setBrainState("speaking"),
      onEnd: () => setBrainState("idle"),
    });
  };

  return { toggleListening, speak };
}
