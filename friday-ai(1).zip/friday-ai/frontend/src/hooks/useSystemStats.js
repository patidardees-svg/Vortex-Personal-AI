import { useEffect, useRef } from "react";
import { SystemStatsSocket } from "../services/websocket";
import { useFridayStore } from "../store/fridayStore";

/**
 * Subscribes to the live system stats WebSocket feed and updates
 * the global store (used by the dashboard widgets).
 */
export function useSystemStats() {
  const setSystemStats = useFridayStore((s) => s.setSystemStats);
  const socketRef = useRef(null);

  useEffect(() => {
    const socket = new SystemStatsSocket();
    socketRef.current = socket;
    socket.connect();

    const unsubscribe = socket.subscribe((data) => setSystemStats(data));

    return () => {
      unsubscribe();
      socket.disconnect();
    };
  }, []);
}
