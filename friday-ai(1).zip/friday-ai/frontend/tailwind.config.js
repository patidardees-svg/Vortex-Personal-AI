/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        void: "#04060c",
        abyss: "#070b14",
        panel: "#0b121f",
        cyan: {
          glow: "#5ef3ff",
          core: "#00d4ff",
          deep: "#0091b3",
        },
        amber: {
          alert: "#ff8a3d",
        },
      },
      fontFamily: {
        display: ["Orbitron", "sans-serif"],
        body: ["Rajdhani", "sans-serif"],
        mono: ["Share Tech Mono", "monospace"],
      },
      boxShadow: {
        "glow-cyan": "0 0 20px rgba(94, 243, 255, 0.45), 0 0 60px rgba(0, 212, 255, 0.15)",
        "glow-cyan-lg": "0 0 40px rgba(94, 243, 255, 0.5), 0 0 120px rgba(0, 212, 255, 0.25)",
      },
      animation: {
        "pulse-slow": "pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        scanline: "scanline 6s linear infinite",
        flicker: "flicker 3s linear infinite",
      },
      keyframes: {
        scanline: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" },
        },
        flicker: {
          "0%, 100%": { opacity: 1 },
          "92%": { opacity: 1 },
          "93%": { opacity: 0.6 },
          "94%": { opacity: 1 },
        },
      },
      backdropBlur: {
        xs: "2px",
      },
    },
  },
  plugins: [],
};
