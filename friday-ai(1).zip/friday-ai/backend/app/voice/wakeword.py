"""
Wake word detection. Lightweight keyword-spotting using the transcribed
text from the STT stream — checks whether the configured wake word
("friday") appears. For production, replace with a dedicated streaming
wake-word model (e.g. Porcupine, openWakeWord) running client-side for
lower latency.
"""
from app.config import settings


def contains_wake_word(text: str) -> bool:
    """Return True if the wake word is present in the transcribed text."""
    return settings.WAKE_WORD.lower() in text.lower()


def strip_wake_word(text: str) -> str:
    """Remove the wake word from the start of a command, if present."""
    wake = settings.WAKE_WORD.lower()
    lowered = text.lower().strip()
    if lowered.startswith(wake):
        return text.strip()[len(wake):].strip(" ,.")
    return text.strip()
