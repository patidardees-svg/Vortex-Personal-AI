"""
Speech-to-text using faster-whisper. Accepts raw audio bytes (wav/pcm)
and returns transcribed text. Model is loaded lazily and cached.
"""
import io
import tempfile
from functools import lru_cache

from app.config import settings


@lru_cache
def _get_model():
    from faster_whisper import WhisperModel
    return WhisperModel(settings.WHISPER_MODEL_SIZE, device="cpu", compute_type="int8")


def transcribe_audio(audio_bytes: bytes) -> str:
    """Transcribe audio bytes (WAV format) to text."""
    model = _get_model()

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as tmp:
        tmp.write(audio_bytes)
        tmp.flush()
        segments, _info = model.transcribe(tmp.name, beam_size=5)
        text = " ".join(seg.text.strip() for seg in segments)

    return text.strip()
