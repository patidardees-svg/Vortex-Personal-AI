"""
Text-to-speech engine. Generates audio bytes from text. Uses pyttsx3
for offline synthesis; swap for a cloud TTS (ElevenLabs, Azure, OpenAI TTS)
for production-quality voice.
"""
import io
import tempfile
import os


def synthesize_speech(text: str) -> bytes:
    """Convert text to speech audio (WAV bytes)."""
    import pyttsx3

    engine = pyttsx3.init()
    engine.setProperty("rate", 185)

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        path = tmp.name

    engine.save_to_file(text, path)
    engine.runAndWait()

    with open(path, "rb") as f:
        audio_bytes = f.read()

    os.remove(path)
    return audio_bytes
