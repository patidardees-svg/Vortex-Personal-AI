"""
FRIDAY AI - FastAPI application entrypoint.
Wires together all routers, middleware, and startup tasks.
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database.session import init_db
from app.api import chat, voice, memory, automation, system


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(title=settings.APP_NAME, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router)
app.include_router(voice.router)
app.include_router(memory.router)
app.include_router(automation.router)
app.include_router(system.router)


@app.get("/")
async def root():
    return {"name": settings.APP_NAME, "status": "online", "env": settings.ENV}


@app.get("/health")
async def health():
    return {"status": "ok"}
