"""
Memory engine: orchestrates short-term buffer, long-term persistence,
and semantic (vector) recall to build context for the LLM.
"""
from app.database.memory_store import memory_store


class MemoryEngine:
    async def build_context(self, conversation_id: str, user_message: str) -> tuple[list[dict], str]:
        """
        Returns:
          - history: short-term rolling conversation (role/content list)
          - memory_context: stringified relevant long-term memories
        """
        history = memory_store.get_short_term(conversation_id)

        # Semantic recall from long-term vector memory
        recalled = memory_store.semantic_recall(user_message, top_k=3)
        relevant = [m for m in recalled if m["similarity"] > 0.75]

        memory_context = "\n".join(f"- {m['text']}" for m in relevant) if relevant else ""

        return history, memory_context

    async def record_turn(self, conversation_id: str, role: str, content: str) -> None:
        memory_store.push_short_term(conversation_id, role, content)
        await memory_store.persist_message(conversation_id, role, content)


memory_engine = MemoryEngine()
