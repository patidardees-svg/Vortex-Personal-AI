"""
Tool definitions FRIDAY can invoke: open applications, run shell commands,
schedule tasks, fetch system stats. Each tool is a callable with metadata
so the planner/LLM can select and invoke them safely.
"""
import asyncio
import platform
import subprocess
from dataclasses import dataclass
from typing import Callable, Awaitable, Any

import psutil

try:
    import GPUtil
except ImportError:
    GPUtil = None


@dataclass
class ToolResult:
    success: bool
    output: str
    data: dict | None = None


# --------------------------------------------------------------------------
# Application launcher
# --------------------------------------------------------------------------
APP_COMMANDS = {
    "windows": {
        "notepad": "notepad",
        "calculator": "calc",
        "browser": "start chrome",
        "explorer": "explorer",
    },
    "darwin": {
        "notepad": "open -a TextEdit",
        "calculator": "open -a Calculator",
        "browser": "open -a 'Google Chrome'",
        "explorer": "open .",
    },
    "linux": {
        "notepad": "gedit",
        "calculator": "gnome-calculator",
        "browser": "xdg-open https://google.com",
        "explorer": "xdg-open .",
    },
}


async def open_application(app_name: str) -> ToolResult:
    """Launch a known application by friendly name."""
    system = platform.system().lower()
    commands = APP_COMMANDS.get(system, {})
    cmd = commands.get(app_name.lower())

    if not cmd:
        return ToolResult(False, f"No mapping found for '{app_name}' on {system}.")

    try:
        subprocess.Popen(cmd, shell=True)
        return ToolResult(True, f"Opening {app_name}...")
    except Exception as exc:  # noqa: BLE001
        return ToolResult(False, f"Failed to open {app_name}: {exc}")


# --------------------------------------------------------------------------
# Shell command execution (sandboxed allow-list in production!)
# --------------------------------------------------------------------------
SAFE_COMMAND_PREFIXES = ("echo", "dir", "ls", "pwd", "whoami", "date")


async def execute_command(command: str) -> ToolResult:
    """Execute a whitelisted shell command and return its output."""
    if not command.strip().startswith(SAFE_COMMAND_PREFIXES):
        return ToolResult(False, "Command rejected: not in the safe allow-list.")

    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        output = stdout.decode().strip() or stderr.decode().strip()
        return ToolResult(True, output, {"returncode": proc.returncode})
    except Exception as exc:  # noqa: BLE001
        return ToolResult(False, f"Execution failed: {exc}")


# --------------------------------------------------------------------------
# System monitoring
# --------------------------------------------------------------------------
def get_system_stats() -> dict[str, Any]:
    """Return current CPU, RAM, disk, network, and GPU usage."""
    cpu = psutil.cpu_percent(interval=0.2)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()

    gpu_data = []
    if GPUtil:
        try:
            for gpu in GPUtil.getGPUs():
                gpu_data.append({
                    "name": gpu.name,
                    "load": round(gpu.load * 100, 1),
                    "memoryUsed": gpu.memoryUsed,
                    "memoryTotal": gpu.memoryTotal,
                    "temperature": gpu.temperature,
                })
        except Exception:
            gpu_data = []

    return {
        "cpu": cpu,
        "ram": {
            "percent": mem.percent,
            "used": mem.used,
            "total": mem.total,
        },
        "disk": {
            "percent": disk.percent,
            "used": disk.used,
            "total": disk.total,
        },
        "network": {
            "sent": net.bytes_sent,
            "recv": net.bytes_recv,
        },
        "gpu": gpu_data,
    }


# --------------------------------------------------------------------------
# Tool registry exposed to the reasoning engine
# --------------------------------------------------------------------------
TOOL_REGISTRY: dict[str, Callable[..., Awaitable[ToolResult]]] = {
    "open_application": open_application,
    "execute_command": execute_command,
}
