"""
Thin wrapper around the LLM provider (OpenAI-compatible).
Supports streaming token generation for real-time WebSocket responses.
"""
from collections.abc import AsyncGenerator
from openai import AsyncOpenAI
from app.config import settings

SYSTEM_PROMPT = """You are FRIDAY, an advanced AI assistant inspired by Tony Stark's
AI systems. You are sharp, efficient, warm but professional, and slightly witty.
You have access to memory of past conversations and user preferences. Keep responses
concise unless the user asks for detail. When you take an action (open app, run a
command, schedule a task), acknowledge it clearly."""


class LLMClient:
    def __init__(self) -> None:
        self._client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY) if settings.OPENAI_API_KEY else None

    async def stream_chat(
        self,
        user_message: str,
        history: list[dict],
        memory_context: str = "",
    ) -> AsyncGenerator[str, None]:
        """Yield response tokens as they are generated."""
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        if memory_context:
            messages.append({
                "role": "system",
                "content": f"Relevant memory context:\n{memory_context}",
            })

        messages.extend(history)
        messages.append({"role": "user", "content": user_message})

        if not self._client:
            # Dev fallback: simulate streaming without an API key
            async for chunk in self._mock_stream(user_message):
                yield chunk
            return

        stream = await self._client.chat.completions.create(
            model=settings.LLM_MODEL,
            messages=messages,
            stream=True,
            temperature=0.7,
        )
        async for event in stream:
            delta = event.choices[0].delta.content
            if delta:
                yield delta

    async def _mock_stream(self, user_message: str) -> AsyncGenerator[str, None]:
        import asyncio
        response = (
            f"I heard you say: '{user_message}'. "
            "I'm running in offline mode right now since no API key is configured, "
            "but my systems are fully online and ready."
        )
        for word in response.split(" "):
            await asyncio.sleep(0.04)
            yield word + " "


llm_client = LLMClient()
