"""
Reasoning engine: the central orchestrator. For each user message it:
 1. Builds memory context (short + long term)
 2. Plans the intent (chat vs tool execution)
 3. Executes tools if needed
 4. Streams an LLM response (with tool results injected as context)
"""
from collections.abc import AsyncGenerator

from app.ai.llm import llm_client
from app.ai.memory_engine import memory_engine
from app.ai.planner import create_plan
from app.ai.tools import open_application, execute_command, get_system_stats


class ReasoningEngine:
    async def handle_message(
        self, conversation_id: str, user_message: str
    ) -> AsyncGenerator[dict, None]:
        """
        Yields structured events for the WebSocket layer:
          {"type": "status", "data": "..."}
          {"type": "token", "data": "..."}
          {"type": "done", "data": {"full_text": "..."}}
        """
        history, memory_context = await memory_engine.build_context(conversation_id, user_message)
        await memory_engine.record_turn(conversation_id, "user", user_message)

        plan = create_plan(user_message)
        tool_note = ""

        if plan.intent == "open_app":
            yield {"type": "status", "data": "executing_tool"}
            result = await open_application(plan.payload["app_name"])
            tool_note = f"[Tool result] {result.output}"

        elif plan.intent == "run_command":
            yield {"type": "status", "data": "executing_tool"}
            result = await execute_command(plan.payload["command"])
            tool_note = f"[Command output] {result.output}"

        elif plan.intent == "system_status":
            yield {"type": "status", "data": "fetching_system_stats"}
            stats = get_system_stats()
            tool_note = (
                f"[System Status] CPU: {stats['cpu']}%, "
                f"RAM: {stats['ram']['percent']}%, "
                f"Disk: {stats['disk']['percent']}%"
            )
            yield {"type": "system_stats", "data": stats}

        elif plan.intent == "schedule_task":
            tool_note = "[Note] Task scheduling request detected. Confirm details with the user."

        yield {"type": "status", "data": "thinking"}

        combined_context = memory_context
        if tool_note:
            combined_context = f"{memory_context}\n{tool_note}".strip()

        full_text = ""
        async for token in llm_client.stream_chat(user_message, history, combined_context):
            full_text += token
            yield {"type": "token", "data": token}

        await memory_engine.record_turn(conversation_id, "assistant", full_text)
        yield {"type": "done", "data": {"full_text": full_text}}


reasoning_engine = ReasoningEngine()
