"""
Intent planner: lightweight rule-based + LLM-assisted intent classification
that decides whether a user message requires a tool call (automation) or
a plain conversational response. This keeps tool execution deterministic
and auditable rather than fully agentic/unbounded.
"""
import re
from dataclasses import dataclass


@dataclass
class Plan:
    intent: str  # "chat" | "open_app" | "run_command" | "system_status" | "schedule_task"
    payload: dict


OPEN_APP_PATTERN = re.compile(r"\bopen\s+(?:the\s+)?([a-zA-Z ]+)", re.IGNORECASE)
RUN_CMD_PATTERN = re.compile(r"\brun (?:command|cmd)[: ]+(.+)", re.IGNORECASE)
STATUS_KEYWORDS = ("system status", "cpu usage", "ram usage", "how is the system", "performance")
SCHEDULE_PATTERN = re.compile(r"\bschedule\b", re.IGNORECASE)


def create_plan(message: str) -> Plan:
    """Classify the user's message into an actionable plan."""
    text = message.strip()

    if match := OPEN_APP_PATTERN.search(text):
        return Plan(intent="open_app", payload={"app_name": match.group(1).strip()})

    if match := RUN_CMD_PATTERN.search(text):
        return Plan(intent="run_command", payload={"command": match.group(1).strip()})

    if any(kw in text.lower() for kw in STATUS_KEYWORDS):
        return Plan(intent="system_status", payload={})

    if SCHEDULE_PATTERN.search(text):
        return Plan(intent="schedule_task", payload={"raw": text})

    return Plan(intent="chat", payload={"message": text})
