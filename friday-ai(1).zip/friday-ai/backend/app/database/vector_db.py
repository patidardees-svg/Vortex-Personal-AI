"""
Vector database wrapper around ChromaDB for semantic memory search.
Embeddings are generated via OpenAI embedding model (swap-able).
"""
import chromadb
from chromadb.config import Settings as ChromaSettings
from openai import OpenAI
from app.config import settings


class VectorMemoryStore:
    """Stores and retrieves long-term memories via vector similarity search."""

    def __init__(self) -> None:
        self._client = chromadb.PersistentClient(
            path=settings.CHROMA_PERSIST_DIR,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self._collection = self._client.get_or_create_collection(
            name=settings.CHROMA_COLLECTION
        )
        self._openai = OpenAI(api_key=settings.OPENAI_API_KEY) if settings.OPENAI_API_KEY else None

    def _embed(self, text: str) -> list[float]:
        if self._openai:
            resp = self._openai.embeddings.create(
                model=settings.EMBEDDING_MODEL, input=text
            )
            return resp.data[0].embedding
        # Fallback deterministic pseudo-embedding (dev mode without API key)
        import hashlib
        h = hashlib.sha256(text.encode()).digest()
        return [b / 255.0 for b in h[:32]]

    def add_memory(self, memory_id: str, text: str, metadata: dict | None = None) -> None:
        embedding = self._embed(text)
        self._collection.add(
            ids=[memory_id],
            embeddings=[embedding],
            documents=[text],
            metadatas=[metadata or {}],
        )

    def search(self, query: str, top_k: int = 5) -> list[dict]:
        embedding = self._embed(query)
        results = self._collection.query(query_embeddings=[embedding], n_results=top_k)

        memories = []
        ids = results.get("ids", [[]])[0]
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        dists = results.get("distances", [[]])[0]

        for i, doc, meta, dist in zip(ids, docs, metas, dists):
            memories.append({
                "id": i,
                "text": doc,
                "metadata": meta,
                "similarity": 1 - dist,
            })
        return memories

    def delete_memory(self, memory_id: str) -> None:
        self._collection.delete(ids=[memory_id])


vector_store = VectorMemoryStore()
