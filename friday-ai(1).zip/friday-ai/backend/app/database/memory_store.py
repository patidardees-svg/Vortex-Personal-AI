"""
Unified memory store combining:
- Short-term memory: in-process rolling buffer per conversation (fast, ephemeral)
- Long-term memory: persisted to Postgres (Message table) + ChromaDB (semantic)
- User profile: key/value facts about the user
"""
from collections import deque, defaultdict
from datetime import datetime
import uuid

from sqlalchemy import select
from app.database.session import AsyncSessionLocal
from app.database.models import Message, Conversation, UserProfile
from app.database.vector_db import vector_store


class MemoryStore:
    SHORT_TERM_LIMIT = 20

    def __init__(self) -> None:
        # conversation_id -> deque of {role, content}
        self._short_term: dict[str, deque] = defaultdict(
            lambda: deque(maxlen=self.SHORT_TERM_LIMIT)
        )

    # ---------- Short-term memory ----------
    def push_short_term(self, conversation_id: str, role: str, content: str) -> None:
        self._short_term[conversation_id].append({"role": role, "content": content})

    def get_short_term(self, conversation_id: str) -> list[dict]:
        return list(self._short_term[conversation_id])

    # ---------- Long-term memory (Postgres + Vector) ----------
    async def persist_message(self, conversation_id: str, role: str, content: str) -> None:
        async with AsyncSessionLocal() as session:
            convo = await session.get(Conversation, conversation_id)
            if not convo:
                convo = Conversation(id=conversation_id, title=content[:40])
                session.add(convo)

            msg = Message(
                id=str(uuid.uuid4()),
                conversation_id=conversation_id,
                role=role,
                content=content,
            )
            session.add(msg)
            await session.commit()

        # Index in vector store for semantic recall (only meaningful turns)
        if role in ("user", "assistant") and len(content.strip()) > 0:
            vector_store.add_memory(
                memory_id=f"{conversation_id}-{uuid.uuid4()}",
                text=content,
                metadata={"role": role, "conversation_id": conversation_id, "ts": str(datetime.utcnow())},
            )

    async def get_conversation_history(self, conversation_id: str, limit: int = 50) -> list[dict]:
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                select(Message)
                .where(Message.conversation_id == conversation_id)
                .order_by(Message.created_at.asc())
                .limit(limit)
            )
            rows = result.scalars().all()
            return [{"role": m.role, "content": m.content, "created_at": m.created_at.isoformat()} for m in rows]

    # ---------- Vector / semantic search ----------
    def semantic_recall(self, query: str, top_k: int = 5) -> list[dict]:
        return vector_store.search(query, top_k=top_k)

    # ---------- User profile memory ----------
    async def set_profile_fact(self, key: str, value: str) -> None:
        async with AsyncSessionLocal() as session:
            result = await session.execute(select(UserProfile).where(UserProfile.key == key))
            existing = result.scalar_one_or_none()
            if existing:
                existing.value = value
                existing.updated_at = datetime.utcnow()
            else:
                session.add(UserProfile(key=key, value=value))
            await session.commit()

    async def get_profile(self) -> dict[str, str]:
        async with AsyncSessionLocal() as session:
            result = await session.execute(select(UserProfile))
            return {row.key: row.value for row in result.scalars().all()}


memory_store = MemoryStore()
