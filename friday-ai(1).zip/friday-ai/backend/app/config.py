"""
Application configuration using pydantic-settings.
Loads environment variables from .env file.
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    APP_NAME: str = "FRIDAY AI"
    ENV: str = "development"
    DEBUG: bool = True

    # CORS
    ALLOWED_ORIGINS: list[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://friday:friday@localhost:5432/friday_db"

    # Vector DB (ChromaDB)
    CHROMA_PERSIST_DIR: str = "./chroma_store"
    CHROMA_COLLECTION: str = "friday_memory"

    # LLM
    OPENAI_API_KEY: str = ""
    LLM_MODEL: str = "gpt-4o-mini"
    EMBEDDING_MODEL: str = "text-embedding-3-small"

    # Voice
    WHISPER_MODEL_SIZE: str = "base"
    TTS_VOICE: str = "default"
    WAKE_WORD: str = "friday"

    # WebSocket
    WS_HEARTBEAT_INTERVAL: int = 30

    class Config:
        env_file = ".env"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
