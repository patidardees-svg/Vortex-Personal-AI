"""
Memory API: inspect short/long-term memory, run semantic search,
and manage user profile facts.
"""
from fastapi import APIRouter
from pydantic import BaseModel

from app.database.memory_store import memory_store

router = APIRouter(prefix="/api/memory", tags=["memory"])


class ProfileFact(BaseModel):
    key: str
    value: str


class SemanticQuery(BaseModel):
    query: str
    top_k: int = 5


@router.get("/short-term/{conversation_id}")
async def short_term(conversation_id: str):
    return {"conversation_id": conversation_id, "messages": memory_store.get_short_term(conversation_id)}


@router.post("/search")
async def semantic_search(payload: SemanticQuery):
    results = memory_store.semantic_recall(payload.query, top_k=payload.top_k)
    return {"results": results}


@router.get("/profile")
async def get_profile():
    return await memory_store.get_profile()


@router.post("/profile")
async def set_profile(fact: ProfileFact):
    await memory_store.set_profile_fact(fact.key, fact.value)
    return {"success": True}
