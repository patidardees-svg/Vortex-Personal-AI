"""
Automation API: open applications, run commands, and manage
scheduled tasks via APScheduler.
"""
from fastapi import APIRouter
from pydantic import BaseModel
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import uuid

from app.ai.tools import open_application, execute_command

router = APIRouter(prefix="/api/automation", tags=["automation"])

scheduler = AsyncIOScheduler()
scheduler.start()

_tasks: dict[str, dict] = {}


class OpenAppRequest(BaseModel):
    app_name: str


class CommandRequest(BaseModel):
    command: str


class ScheduleRequest(BaseModel):
    name: str
    command: str
    cron: str  # e.g. "0 9 * * *"


@router.post("/open-app")
async def open_app(req: OpenAppRequest):
    result = await open_application(req.app_name)
    return {"success": result.success, "output": result.output}


@router.post("/execute")
async def execute(req: CommandRequest):
    result = await execute_command(req.command)
    return {"success": result.success, "output": result.output, "data": result.data}


@router.post("/schedule")
async def schedule_task(req: ScheduleRequest):
    task_id = str(uuid.uuid4())

    async def job():
        await execute_command(req.command)

    trigger = CronTrigger.from_crontab(req.cron)
    scheduler.add_job(job, trigger, id=task_id)

    _tasks[task_id] = {"name": req.name, "command": req.command, "cron": req.cron, "enabled": True}
    return {"task_id": task_id, **_tasks[task_id]}


@router.get("/tasks")
async def list_tasks():
    return {"tasks": [{"id": k, **v} for k, v in _tasks.items()]}


@router.delete("/tasks/{task_id}")
async def delete_task(task_id: str):
    if task_id in _tasks:
        scheduler.remove_job(task_id)
        del _tasks[task_id]
        return {"success": True}
    return {"success": False, "error": "Task not found"}
