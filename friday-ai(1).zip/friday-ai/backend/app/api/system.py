"""
System API: REST + WebSocket endpoints for live system monitoring
(CPU, RAM, disk, network, GPU) used by the dashboard.
"""
import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.ai.tools import get_system_stats

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("/stats")
async def stats():
    return get_system_stats()


@router.websocket("/ws/stats")
async def stats_stream(websocket: WebSocket):
    """Push system stats to the client every 2 seconds."""
    await websocket.accept()
    try:
        while True:
            await websocket.send_json(get_system_stats())
            await asyncio.sleep(2)
    except WebSocketDisconnect:
        pass
