"""
Chat API: WebSocket endpoint for real-time streaming conversation,
plus REST endpoints for fetching conversation history.
"""
import json
import uuid

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.ai.reasoning import reasoning_engine
from app.database.memory_store import memory_store

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.get("/history/{conversation_id}")
async def get_history(conversation_id: str):
    history = await memory_store.get_conversation_history(conversation_id)
    return {"conversation_id": conversation_id, "messages": history}


@router.get("/new")
async def new_conversation():
    return {"conversation_id": str(uuid.uuid4())}


@router.websocket("/ws/{conversation_id}")
async def chat_websocket(websocket: WebSocket, conversation_id: str):
    """
    Real-time chat stream.

    Client sends: {"type": "user_message", "data": "<text>"}
    Server sends a sequence of events:
      {"type": "status", "data": "thinking" | "executing_tool" | "fetching_system_stats"}
      {"type": "token", "data": "<partial text>"}
      {"type": "system_stats", "data": {...}}
      {"type": "done", "data": {"full_text": "..."}}
      {"type": "error", "data": "<message>"}
    """
    await websocket.accept()
    try:
        while True:
            raw = await websocket.receive_text()
            message = json.loads(raw)

            if message.get("type") != "user_message":
                continue

            user_text = message.get("data", "")
            if not user_text.strip():
                continue

            try:
                async for event in reasoning_engine.handle_message(conversation_id, user_text):
                    await websocket.send_json(event)
            except Exception as exc:  # noqa: BLE001
                await websocket.send_json({"type": "error", "data": str(exc)})

    except WebSocketDisconnect:
        pass
