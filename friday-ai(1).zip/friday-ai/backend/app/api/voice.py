"""
Voice API: speech-to-text and text-to-speech REST endpoints,
plus wake-word checking.
"""
from fastapi import APIRouter, UploadFile, File
from fastapi.responses import StreamingResponse
import io

from app.voice.stt import transcribe_audio
from app.voice.tts import synthesize_speech
from app.voice.wakeword import contains_wake_word, strip_wake_word

router = APIRouter(prefix="/api/voice", tags=["voice"])


@router.post("/stt")
async def speech_to_text(audio: UploadFile = File(...)):
    """Transcribe uploaded audio (WAV) into text and detect wake word."""
    audio_bytes = await audio.read()
    text = transcribe_audio(audio_bytes)

    return {
        "text": text,
        "wake_word_detected": contains_wake_word(text),
        "command": strip_wake_word(text),
    }


@router.post("/tts")
async def text_to_speech(payload: dict):
    """Synthesize speech audio from text and stream WAV back."""
    text = payload.get("text", "")
    audio_bytes = synthesize_speech(text)
    return StreamingResponse(io.BytesIO(audio_bytes), media_type="audio/wav")
