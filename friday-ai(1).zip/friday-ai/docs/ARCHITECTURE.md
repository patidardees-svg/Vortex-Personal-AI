# FRIDAY — System Architecture

## Data Flow

```
┌──────────────┐      WebSocket       ┌───────────────────┐
│   Frontend    │ <──────────────────> │   FastAPI Backend  │
│  (React/R3F)  │   /api/chat/ws/:id    │                    │
└──────┬────────┘                      └─────────┬──────────┘
       │                                          │
       │ user_message                            ▼
       │                              ┌─────────────────────┐
       │                              │  Reasoning Engine    │
       │                              │  - Planner (intent)  │
       │                              │  - Memory Engine     │
       │                              │  - Tool Executor     │
       │                              │  - LLM Stream        │
       │                              └─────┬───────┬────────┘
       │                                    │       │
       │                       ┌────────────┘       └─────────────┐
       │                       ▼                                   ▼
       │            ┌───────────────────┐               ┌───────────────────┐
       │            │  Memory Store      │               │  Tools             │
       │            │  - Short-term      │               │  - open_app        │
       │            │    (in-memory)     │               │  - execute_command │
       │            │  - Long-term (PG)  │               │  - system_stats     │
       │            │  - Vector (Chroma) │               └───────────────────┘
       │            └───────────────────┘
       │
       ▼
┌──────────────┐
│ Brain / Voice │  status/token/done events drive:
│ Visualization │  - brainState (idle/listening/thinking/speaking)
│   (R3F)       │  - particle pulse, synapse speed, voice ring
└──────────────┘
```

## Component Responsibilities

- **Planner** (`app/ai/planner.py`): regex/keyword-based intent classification.
  Deterministic and auditable — avoids unbounded agentic tool calls.
- **Memory Engine** (`app/ai/memory_engine.py`): builds LLM context from a
  rolling short-term buffer plus semantically-relevant long-term memories
  (similarity > 0.75 threshold).
- **Reasoning Engine** (`app/ai/reasoning.py`): the orchestrator. Emits
  structured WebSocket events consumed directly by the frontend's brain
  visualization and chat UI.
- **Tools** (`app/ai/tools.py`): cross-platform app launching, whitelisted
  shell execution, and `psutil`/`GPUtil`-based system telemetry.

## Brain Rendering Pipeline

1. `ParticleSystem.jsx` — 6,000-particle `Points` mesh on a noisy sphere
   shell; per-frame radial pulse driven by `brainState` + mic amplitude.
2. `SynapseLines.jsx` — 50 line segments with traveling pulse spheres,
   speed scales with `brainState`.
3. `BrainEffects.jsx` — emissive core sphere, additive glow sphere, and two
   rotating HUD torus rings.
4. `NeuralBrain.jsx` — composes the above inside a single `Canvas`, applies
   `Bloom` + `Vignette` post-processing, and auto-rotates via `OrbitControls`.
